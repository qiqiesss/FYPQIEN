(function (window) {
  'use strict';

  const Clinic = window.Clinic || {};
  const app = Clinic.app || {};
  const utils = Clinic.utils || {};

  function getReminders() {
    if (!Clinic.REMINDERS || Clinic.REMINDERS.length === 0) {
      if (Clinic.APPOINTMENTS && Clinic.utils && Clinic.reminders) {
        const tomDate = Clinic.utils.tomorrowDate();
        const tomISO = Clinic.utils.toDateISO(tomDate);
        const appts = Clinic.APPOINTMENTS.filter(a => a.dateISO === tomISO);
        Clinic.REMINDERS = appts.map(a => Clinic.reminders.buildReminderForAppt(a, tomDate, 'Queued'));
        if (Clinic.REMINDERS.length > 0) {
          Clinic.REMINDERS[0].status = 'Failed';
        }
      }
    }
    return Clinic.REMINDERS || [];
  }

  function refreshStats() {
    const chips = document.getElementById('statChips');
    if (!chips) return;
    chips.innerHTML = '';
    const reminders = getReminders();
    const queued = reminders.filter((r) => r.status === 'Queued').length;
    const sent = reminders.filter((r) => r.status === 'Sent').length;
    const failed = reminders.filter((r) => r.status === 'Failed').length;
    const stats = [
      { label: 'Queued', value: queued, cls: 'queued' },
      { label: 'Sent', value: sent, cls: 'sent' },
      { label: 'Failed', value: failed, cls: 'failed' }
    ];
    stats.forEach(function (s) {
      const chip = document.createElement('span');
      chip.className = 'stat-chip ' + s.cls;
      chip.textContent = s.label + ': ' + s.value;
      chips.appendChild(chip);
    });
  }

  function statusBadge(status) {
    const badge = document.createElement('span');
    badge.className = 'status-badge ' + status.toLowerCase();
    badge.textContent = status;
    return badge;
  }

  let currentPreviewModal = null;
  function openMessagePreview(r) {
    const nameEl = document.getElementById('previewPatientName');
    const phoneEl = document.getElementById('previewPatientPhone');
    const msgEl = document.getElementById('previewMessageContent');
    const timeEl = document.getElementById('previewTimestamp');
    const readEl = document.getElementById('previewReadReceipt');
    
    if (nameEl) nameEl.textContent = r.patientName;
    if (phoneEl) phoneEl.textContent = r.phone;
    if (msgEl) msgEl.textContent = r.message;
    
    if (timeEl) {
      const now = new Date();
      timeEl.textContent = now.getHours() + ':' + String(now.getMinutes()).padStart(2, '0');
    }
    
    if (readEl) {
      if (r.status === 'Sent') {
        readEl.style.display = 'inline-block';
        readEl.className = 'bi bi-check-all text-info'; // Blue ticks
      } else {
        readEl.style.display = 'inline-block';
        readEl.className = 'bi bi-check'; // Single tick
        readEl.style.color = '#667781';
      }
    }

    if (!currentPreviewModal && window.bootstrap) {
      currentPreviewModal = new bootstrap.Modal(document.getElementById('messagePreviewModal'));
    }
    if (currentPreviewModal) currentPreviewModal.show();
  }

  let currentEditModal = null;
  function openEditMessageModal(r) {
    const textarea = document.getElementById('editMessageContent');
    const idInput = document.getElementById('editMessageId');
    if (textarea) textarea.value = r.message;
    if (idInput) idInput.value = r.id;
    
    if (!currentEditModal && window.bootstrap) {
      currentEditModal = new bootstrap.Modal(document.getElementById('editMessageModal'));
    }
    if (currentEditModal) currentEditModal.show();
  }

  function renderRows() {
    const body = document.getElementById('remindersBody');
    if (!body) return;
    body.innerHTML = '';
    const reminders = getReminders();
    reminders.forEach(function (r) {
      const tr = document.createElement('tr');

      const tdPatient = document.createElement('td');
      tdPatient.textContent = r.patientName;

      const tdPhone = document.createElement('td');
      tdPhone.textContent = r.phone;

      const tdTime = document.createElement('td');
      tdTime.textContent = r.appointmentTime;

      const tdMsg = document.createElement('td');
      tdMsg.className = 'message-preview';
      tdMsg.textContent = r.message;
      
      // Make clickable
      tdMsg.style.cursor = 'pointer';
      tdMsg.title = "Click to view full message details";
      tdMsg.innerHTML = `<div class="d-flex align-items-center gap-2"><i class="bi bi-chat-left-text text-primary"></i> <span style="text-decoration: underline; color: #2563eb; text-decoration-color: #93c5fd; text-underline-offset: 3px;">${r.message.substring(0, 45)}...</span></div>`;
      tdMsg.addEventListener('click', function() {
        openMessagePreview(r);
      });

      const tdStatus = document.createElement('td');
      tdStatus.appendChild(statusBadge(r.status));

      const tdAction = document.createElement('td');
      if (r.status === 'Failed') {
        const retryBtn = document.createElement('button');
        retryBtn.className = 'btn ghost';
        retryBtn.textContent = 'Retry';
        retryBtn.addEventListener('click', function () {
          retryBtn.disabled = true;
          retryBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Retrying...';
          setTimeout(function () {
            r.status = 'Sent';
            renderRows();
            refreshStats();
            if (app.showToast) {
              app.showToast('Reminder sent successfully — ' + r.patientName, 'success');
            }
          }, 1000);
        });
        tdAction.appendChild(retryBtn);
      } else if (r.status === 'Queued') {
        const editBtn = document.createElement('button');
        editBtn.className = 'btn btn-sm btn-outline-primary fw-bold';
        editBtn.innerHTML = '<i class="bi bi-pencil-square"></i> Edit';
        editBtn.addEventListener('click', function() {
          openEditMessageModal(r);
        });
        tdAction.appendChild(editBtn);
      } else {
        tdAction.textContent = '—';
      }

      tr.appendChild(tdPatient);
      tr.appendChild(tdPhone);
      tr.appendChild(tdTime);
      tr.appendChild(tdMsg);
      tr.appendChild(tdStatus);
      tr.appendChild(tdAction);
      body.appendChild(tr);
    });
  }

  function simulateSendAll() {
    const sendBtn = document.getElementById('simulateSendAll');
    if (sendBtn) {
      const originalHTML = sendBtn.innerHTML;
      sendBtn.disabled = true;
      sendBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Dispatching...';

      setTimeout(function () {
        const reminders = getReminders();
        let changed = 0;
        reminders.forEach(function (r) {
          if (r.status === 'Queued') {
            r.status = 'Sent';
            changed++;
          }
        });
        renderRows();
        refreshStats();
        if (app.showToast) {
          if (changed > 0) {
            app.showToast(changed + ' reminder(s) sent — WhatsApp', 'success');
          } else {
            app.showToast('No queued reminders to send', 'info');
          }
        }
        sendBtn.innerHTML = originalHTML;
        sendBtn.disabled = false;
      }, 1500);
    }
  }

  function bindEvents() {
    const sendBtn = document.getElementById('simulateSendAll');
    if (sendBtn) {
      sendBtn.addEventListener('click', simulateSendAll);
    }

    const editForm = document.getElementById('editMessageForm');
    if (editForm) {
      editForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const id = document.getElementById('editMessageId').value;
        const newMsg = document.getElementById('editMessageContent').value;
        
        const reminders = getReminders();
        const rem = reminders.find(x => x.id === id);
        if (rem) {
          rem.message = newMsg;
          renderRows();
          if (app.showToast) {
            app.showToast('Message updated successfully', 'success');
          }
        }
        
        if (currentEditModal) {
          currentEditModal.hide();
        }
      });
    }
  }

  function init() {
    const allowed = app.enforceRole ? app.enforceRole(['admin'], function () {
      const denied = document.getElementById('accessDenied');
      const view = document.getElementById('remindersView');
      if (denied) denied.classList.remove('hidden');
      if (view) view.classList.add('hidden');
      if (app.initRoleBadge) app.initRoleBadge();
      if (app.initLogout) app.initLogout();
      if (app.initBackToIndex) app.initBackToIndex();
    }) : true;
    if (!allowed) return;
    const view = document.getElementById('remindersView');
    if (view) view.classList.remove('hidden');
    if (app.initRoleBadge) app.initRoleBadge();
    if (app.initLogout) app.initLogout();
    if (app.initBackToIndex) app.initBackToIndex();
    renderRows();
    refreshStats();
    bindEvents();
  }

  document.addEventListener('DOMContentLoaded', init);
})(window);