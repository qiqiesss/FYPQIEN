// Reminders Management with Semi-Automatic WhatsApp Integration, Tracking & Filter
document.addEventListener('DOMContentLoaded', () => {
  if (window.Clinic && window.Clinic.app) {
    if (window.Clinic.app.initRoleBadge) window.Clinic.app.initRoleBadge();
    if (window.Clinic.app.initLogout) window.Clinic.app.initLogout();
    if (window.Clinic.app.enforceRole && !window.Clinic.app.enforceRole(['admin'])) return;
  }

  initReminders();
});

let currentLang = localStorage.getItem('kpst.v1.reminder_lang') || 'bm';
let currentDateFilter = 'all'; // 'all', 'tomorrow', 'week'
let activePreviewReminder = null;

function escapeHtml(str) {
  if (window.Clinic && window.Clinic.app && window.Clinic.app.escapeHtml) {
    return window.Clinic.app.escapeHtml(str);
  }
  return String(str || '').replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function cleanPhoneForWa(phone) {
  const digits = String(phone || '').replace(/\D/g, '');
  if (digits.startsWith('0')) return '6' + digits;
  if (digits.startsWith('60')) return digits;
  return '60' + digits;
}

function getStoredReminders() {
  if (!window.Clinic || !window.Clinic.storage) return {};
  return window.Clinic.storage.getJSON(window.Clinic.storage.KEYS.reminders) || {};
}

function setStoredReminders(data) {
  if (!window.Clinic || !window.Clinic.storage) return;
  window.Clinic.storage.setJSON(window.Clinic.storage.KEYS.reminders, data);
}

function getUpcomingRemindersList() {
  if (!window.Clinic || !window.Clinic.APPOINTMENTS) return [];

  const todayDate = window.Clinic.utils.todayDate ? window.Clinic.utils.todayDate() : new Date();
  const todayISO = window.Clinic.utils.toDateISO(todayDate);
  const tomorrowDate = window.Clinic.utils.tomorrowDate ? window.Clinic.utils.tomorrowDate() : new Date(todayDate.getTime() + 86400000);
  const tomorrowISO = window.Clinic.utils.toDateISO(tomorrowDate);

  // 7 days ahead
  const weekEndDate = new Date(todayDate);
  weekEndDate.setDate(weekEndDate.getDate() + 7);
  const weekEndISO = window.Clinic.utils.toDateISO(weekEndDate);

  let upcomingAppts = window.Clinic.APPOINTMENTS.filter(a => {
    if (!a.dateISO) return false;
    if (a.statusPill === 'Canceled') return false;
    return a.dateISO >= tomorrowISO;
  });

  if (currentDateFilter === 'tomorrow') {
    upcomingAppts = upcomingAppts.filter(a => a.dateISO === tomorrowISO);
  } else if (currentDateFilter === 'week') {
    upcomingAppts = upcomingAppts.filter(a => a.dateISO >= tomorrowISO && a.dateISO <= weekEndISO);
  }

  // Sort chronologically by date and time
  upcomingAppts.sort((a, b) => {
    const dComp = a.dateISO.localeCompare(b.dateISO);
    if (dComp !== 0) return dComp;
    return (a.time || '').localeCompare(b.time || '');
  });

  const stored = getStoredReminders();

  return upcomingAppts.map((appt) => {
    const apptDate = new Date(appt.dateISO + 'T00:00:00');
    const base = window.Clinic.reminders.buildReminderForAppt(appt, apptDate, 'Pending', currentLang);
    const saved = stored[base.id] || {};

    return {
      ...base,
      message: saved.message || base.message,
      status: saved.status || 'Pending',
      sentAt: saved.sentAt || null,
      appointment: appt,
      dateISO: appt.dateISO,
      dateObj: apptDate
    };
  });
}

function getTomorrowRemindersList() {
  return getUpcomingRemindersList();
}

function updateStatChips(reminders) {
  const container = document.getElementById('statChips');
  if (!container) return;

  const total = reminders.length;
  const pending = reminders.filter(r => r.status === 'Pending').length;
  const sent = reminders.filter(r => r.status === 'Sent').length;

  container.innerHTML = `
    <span class="stat-chip queued" style="background: #fef9c3; color: #854d0e; border: 1px solid #fef08a;" title="Awaiting reminder dispatch">
      <i class="bi bi-clock-history me-1"></i> Pending: ${pending}
    </span>
    <span class="stat-chip sent" title="Reminder sent via WhatsApp">
      <i class="bi bi-check-circle-fill me-1"></i> Sent: ${sent}
    </span>
    <span class="stat-chip" style="background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0;">
      <i class="bi bi-people me-1"></i> Total: ${total}
    </span>
  `;
}

function markReminderAsSent(id, patientName) {
  const stored = getStoredReminders();
  stored[id] = {
    ...(stored[id] || {}),
    status: 'Sent',
    sentAt: new Date().toISOString()
  };
  setStoredReminders(stored);

  renderRemindersTable();

  if (window.Clinic && window.Clinic.app && window.Clinic.app.showToast) {
    window.Clinic.app.showToast('Reminder Sent', `WhatsApp opened for ${patientName}. Status marked as Sent.`, 'success');
  }
}

function renderRemindersTable() {
  const tbody = document.getElementById('remindersBody');
  if (!tbody) return;

  const reminders = getUpcomingRemindersList();
  tbody.innerHTML = '';

  updateStatChips(reminders);

  if (reminders.length === 0) {
    const filterText = currentDateFilter === 'tomorrow' ? 'for tomorrow' : (currentDateFilter === 'week' ? 'for the next 7 days' : 'for upcoming dates');
    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-muted">No reminders scheduled ${filterText}.</td></tr>`;
    return;
  }

  const tomorrowISO = window.Clinic.utils.toDateISO(window.Clinic.utils.tomorrowDate());

  reminders.forEach(reminder => {
    const isSent = reminder.status === 'Sent';
    const tr = document.createElement('tr');
    tr.id = `row-${reminder.id}`;

    let statusBadge = '';
    let actionHtml = '';

    const cleanPhone = cleanPhoneForWa(reminder.phone);
    const waLink = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(reminder.message)}`;
    const timeFormatted = window.Clinic.utils.formatTime12h(reminder.appointmentTime);

    const isTomorrow = reminder.dateISO === tomorrowISO;
    const dateFormatted = reminder.dateObj ? reminder.dateObj.toLocaleDateString('en-MY', {
      weekday: 'short',
      day: '2-digit',
      month: 'short'
    }) : reminder.dateISO;

    if (isSent) {
      let sentTimeDisplay = '';
      if (reminder.sentAt) {
        const d = new Date(reminder.sentAt);
        const timePart = window.Clinic.utils.formatTime12h(
          String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0')
        );
        sentTimeDisplay = `<small class="d-block text-muted" style="font-size: 0.72rem; margin-top: 2px;">Today at ${timePart}</small>`;
      }
      statusBadge = `
        <span class="badge rounded-pill bg-success-subtle text-success border border-success border-opacity-25 px-2.5 py-1 fw-bold">
          <i class="bi bi-check-circle-fill me-1"></i> Sent
        </span>
        ${sentTimeDisplay}
      `;
      actionHtml = `
        <a href="${waLink}" target="_blank" rel="noopener noreferrer" class="btn-resend send-wa-link" data-id="${reminder.id}" data-patient="${escapeHtml(reminder.patientName)}" title="Resend message via WhatsApp">
          <i class="bi bi-arrow-clockwise"></i> Resend
        </a>
      `;
    } else {
      statusBadge = `
        <span class="badge rounded-pill bg-warning-subtle text-warning border border-warning border-opacity-25 px-2.5 py-1 fw-bold">
          <i class="bi bi-clock me-1"></i> Pending
        </span>
      `;
      actionHtml = `
        <a href="${waLink}" target="_blank" rel="noopener noreferrer" class="btn-send-whatsapp send-wa-link" data-id="${reminder.id}" data-patient="${escapeHtml(reminder.patientName)}">
          <i class="bi bi-whatsapp"></i> Send WhatsApp
        </a>
      `;
    }

    tr.innerHTML = `
      <td style="padding-left: 1.5rem;">
        <div class="d-flex align-items-center">
          <div class="bg-light rounded-circle p-2 me-3 text-secondary d-flex justify-content-center align-items-center shrink-0" style="width:36px;height:36px;">
            <i class="bi bi-person"></i>
          </div>
          <div>
            <span class="fw-bold text-dark d-block">${escapeHtml(reminder.patientName)}</span>
          </div>
        </div>
      </td>
      <td class="text-muted align-middle font-monospace" style="font-size: 0.85rem;">${escapeHtml(reminder.phone)}</td>
      <td class="align-middle">
        <div class="d-flex flex-column">
          <div class="d-flex align-items-center gap-1.5 mb-0.5">
            ${isTomorrow ? '<span class="badge bg-primary-subtle text-primary border border-primary-subtle" style="font-size: 0.68rem; padding: 1px 6px;">Tomorrow</span>' : ''}
            <span class="fw-bold text-dark" style="font-size: 0.88rem;">${dateFormatted}</span>
          </div>
          <span class="text-muted small"><i class="bi bi-clock me-1 text-slate-400"></i>${timeFormatted}</span>
        </div>
      </td>
      <td class="align-middle text-center">
        <div class="d-inline-flex align-items-center gap-1.5 justify-content-center">
          <button class="btn btn-sm btn-light border d-inline-flex align-items-center gap-1 preview-msg-btn" data-msg="${encodeURIComponent(reminder.message)}" data-id="${reminder.id}" data-phone="${cleanPhone}">
            <i class="bi bi-eye text-primary"></i> Preview
          </button>
          <button class="btn btn-sm btn-light border d-inline-flex align-items-center justify-content-center edit-msg-btn" data-msg="${encodeURIComponent(reminder.message)}" data-id="${reminder.id}" data-apptid="${reminder.appointmentId}" style="width: 32px; height: 32px; padding: 0;">
            <i class="bi bi-pencil text-secondary"></i>
          </button>
        </div>
      </td>
      <td class="align-middle text-center status-cell">
        ${statusBadge}
      </td>
      <td class="align-middle text-center action-cell" style="padding-right: 1.5rem;">
        ${actionHtml}
      </td>
    `;

    tbody.appendChild(tr);
  });

  bindTableEvents();
}

function bindTableEvents() {
  // Bind Send WhatsApp / Resend links to track status
  document.querySelectorAll('.send-wa-link').forEach(link => {
    link.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      const patientName = e.currentTarget.getAttribute('data-patient');
      markReminderAsSent(id, patientName);
    });
  });

  // Bind Preview buttons
  document.querySelectorAll('.preview-msg-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const msg = decodeURIComponent(e.currentTarget.getAttribute('data-msg'));
      const cleanPhone = e.currentTarget.getAttribute('data-phone');
      const id = e.currentTarget.getAttribute('data-id');
      const tr = e.currentTarget.closest('tr');
      const patientName = tr.querySelector('.fw-bold').innerText;
      const patientPhone = tr.querySelectorAll('td')[1].innerText;

      activePreviewReminder = { id: id, patientName: patientName };

      document.getElementById('previewMessageContent').innerText = msg;
      document.getElementById('previewPatientName').innerText = patientName;
      document.getElementById('previewPatientPhone').innerText = patientPhone;

      const now = new Date();
      const timeStr = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
      document.getElementById('previewTimestamp').innerText = window.Clinic.utils.formatTime12h(timeStr);

      const waBtn = document.getElementById('previewWaLink');
      if (waBtn) {
        waBtn.href = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
      }

      const modalEl = document.getElementById('messagePreviewModal');
      const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
      modal.show();
    });
  });

  // Bind Edit buttons
  document.querySelectorAll('.edit-msg-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const msg = decodeURIComponent(e.currentTarget.getAttribute('data-msg'));
      const id = e.currentTarget.getAttribute('data-id');
      const apptId = e.currentTarget.getAttribute('data-apptid');

      document.getElementById('editMessageContent').value = msg;
      document.getElementById('editMessageId').value = id;
      document.getElementById('editApptId').value = apptId;

      const modalEl = document.getElementById('editMessageModal');
      const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
      modal.show();
    });
  });
}

function initReminders() {
  // Sync Language Toggle buttons
  const langBM = document.getElementById('langBM');
  const langEN = document.getElementById('langEN');

  function updateLangUI() {
    if (langBM && langEN) {
      if (currentLang === 'en') {
        langEN.classList.add('active');
        langBM.classList.remove('active');
      } else {
        langBM.classList.add('active');
        langEN.classList.remove('active');
      }
    }
  }

  if (langBM) {
    langBM.addEventListener('click', () => {
      if (currentLang === 'bm') return;
      currentLang = 'bm';
      localStorage.setItem('kpst.v1.reminder_lang', 'bm');
      updateLangUI();
      // Re-generate default templates for non-customized reminders
      const stored = getStoredReminders();
      const tomorrowDate = window.Clinic.utils.tomorrowDate();
      const tomorrowISO = window.Clinic.utils.toDateISO(tomorrowDate);
      const upcomingAppts = (window.Clinic.APPOINTMENTS || []).filter(a => a.dateISO && a.dateISO >= tomorrowISO);
      upcomingAppts.forEach(appt => {
        const remId = 'rem-' + appt.id;
        const apptDate = new Date(appt.dateISO + 'T00:00:00');
        const fresh = window.Clinic.reminders.buildReminderForAppt(appt, apptDate, 'Pending', 'bm');
        if (!stored[remId] || !stored[remId].isCustomized) {
          stored[remId] = { ...(stored[remId] || {}), message: fresh.message };
        }
      });
      setStoredReminders(stored);
      renderRemindersTable();
      if (window.Clinic.app && window.Clinic.app.showToast) {
        window.Clinic.app.showToast('Language Updated', 'Reminder templates switched to Bahasa Melayu.', 'info');
      }
    });
  }

  if (langEN) {
    langEN.addEventListener('click', () => {
      if (currentLang === 'en') return;
      currentLang = 'en';
      localStorage.setItem('kpst.v1.reminder_lang', 'en');
      updateLangUI();
      const stored = getStoredReminders();
      const tomorrowDate = window.Clinic.utils.tomorrowDate();
      const tomorrowISO = window.Clinic.utils.toDateISO(tomorrowDate);
      const upcomingAppts = (window.Clinic.APPOINTMENTS || []).filter(a => a.dateISO && a.dateISO >= tomorrowISO);
      upcomingAppts.forEach(appt => {
        const remId = 'rem-' + appt.id;
        const apptDate = new Date(appt.dateISO + 'T00:00:00');
        const fresh = window.Clinic.reminders.buildReminderForAppt(appt, apptDate, 'Pending', 'en');
        if (!stored[remId] || !stored[remId].isCustomized) {
          stored[remId] = { ...(stored[remId] || {}), message: fresh.message };
        }
      });
      setStoredReminders(stored);
      renderRemindersTable();
      if (window.Clinic.app && window.Clinic.app.showToast) {
        window.Clinic.app.showToast('Language Updated', 'Reminder templates switched to English.', 'info');
      }
    });
  }

  updateLangUI();

  // Date Filter Group Controls
  const filterBtns = document.querySelectorAll('#dateFilterGroup button');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      filterBtns.forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      currentDateFilter = e.currentTarget.getAttribute('data-filter') || 'all';
      renderRemindersTable();
    });
  });

  // Preview modal's "Open in WhatsApp" button tracks sent status
  const previewWaBtn = document.getElementById('previewWaLink');
  if (previewWaBtn) {
    previewWaBtn.addEventListener('click', () => {
      if (activePreviewReminder) {
        markReminderAsSent(activePreviewReminder.id, activePreviewReminder.patientName);
      }
    });
  }

  // Edit Message Quick Template Reset Buttons
  const resetBM = document.getElementById('resetTemplateBM');
  const resetEN = document.getElementById('resetTemplateEN');
  const editApptId = document.getElementById('editApptId');
  const editContent = document.getElementById('editMessageContent');

  if (resetBM && editApptId && editContent) {
    resetBM.addEventListener('click', () => {
      const apptId = editApptId.value;
      const appt = (window.Clinic.APPOINTMENTS || []).find(a => a.id === apptId);
      if (appt) {
        const apptDate = appt.dateISO ? new Date(appt.dateISO + 'T00:00:00') : window.Clinic.utils.tomorrowDate();
        const fresh = window.Clinic.reminders.buildReminderForAppt(appt, apptDate, 'Pending', 'bm');
        editContent.value = fresh.message;
      }
    });
  }

  if (resetEN && editApptId && editContent) {
    resetEN.addEventListener('click', () => {
      const apptId = editApptId.value;
      const appt = (window.Clinic.APPOINTMENTS || []).find(a => a.id === apptId);
      if (appt) {
        const apptDate = appt.dateISO ? new Date(appt.dateISO + 'T00:00:00') : window.Clinic.utils.tomorrowDate();
        const fresh = window.Clinic.reminders.buildReminderForAppt(appt, apptDate, 'Pending', 'en');
        editContent.value = fresh.message;
      }
    });
  }

  // Edit Message Form Submission
  const editForm = document.getElementById('editMessageForm');
  if (editForm) {
    editForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const id = document.getElementById('editMessageId').value;
      const newMsg = document.getElementById('editMessageContent').value.trim();

      if (id && newMsg) {
        const stored = getStoredReminders();
        stored[id] = {
          ...(stored[id] || {}),
          message: newMsg,
          isCustomized: true
        };
        setStoredReminders(stored);

        const modalEl = document.getElementById('editMessageModal');
        const modal = bootstrap.Modal.getInstance(modalEl);
        if (modal) modal.hide();

        renderRemindersTable();

        if (window.Clinic && window.Clinic.app && window.Clinic.app.showToast) {
          window.Clinic.app.showToast('Message Updated', 'WhatsApp template updated for this appointment.', 'success');
        }
      }
    });
  }

  renderRemindersTable();
}
