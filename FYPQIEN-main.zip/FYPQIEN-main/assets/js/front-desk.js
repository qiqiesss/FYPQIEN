(function (window) {
  'use strict';

  const Clinic = window.Clinic || {};
  const app = Clinic.app || {};
  const utils = Clinic.utils || {};

  const CLINIC_START = '09:00';
  const CLINIC_END = '17:00';
  const SLOT_INTERVAL_MIN = 30;
  const BUFFER_MIN = 5;

  // Single source of truth for treatment color themes matching legend
  const TREATMENT_THEMES = {
    checkup: {
      id: 'checkup',
      name: 'Check-up',
      color: '#22c55e', // Green
      bg: '#f0fdf4',
      text: '#15803d',
      border: '#22c55e',
      lightBg: '#dcfce7'
    },
    scaling: {
      id: 'scaling',
      name: 'Scaling',
      color: '#3b82f6', // Blue
      bg: '#eff6ff',
      text: '#1e40af',
      border: '#3b82f6',
      lightBg: '#dbeafe'
    },
    filling: {
      id: 'filling',
      name: 'Filling',
      color: '#f59e0b', // Orange/Amber
      bg: '#fffbeb',
      text: '#b45309',
      border: '#f59e0b',
      lightBg: '#fef3c7'
    },
    extraction: {
      id: 'extraction',
      name: 'Extraction',
      color: '#ef4444', // Red
      bg: '#fef2f2',
      text: '#b91c1c',
      border: '#ef4444',
      lightBg: '#fee2e2'
    },
    whitening: {
      id: 'whitening',
      name: 'Whitening',
      color: '#06b6d4', // Cyan
      bg: '#ecfeff',
      text: '#0e7490',
      border: '#06b6d4',
      lightBg: '#cffafe'
    },
    mos: {
      id: 'mos',
      name: 'Minor Oral Surgery',
      color: '#a855f7', // Purple
      bg: '#faf5ff',
      text: '#6b21a8',
      border: '#a855f7',
      lightBg: '#f3e8ff'
    },
    crowns_bridges: {
      id: 'crowns_bridges',
      name: 'Crowns & Bridges',
      color: '#ec4899', // Pink
      bg: '#fdf2f8',
      text: '#be185d',
      border: '#ec4899',
      lightBg: '#fce7f3'
    },
    veneers: {
      id: 'veneers',
      name: 'Veneers',
      color: '#8b5cf6', // Violet
      bg: '#f5f3ff',
      text: '#6d28d9',
      border: '#8b5cf6',
      lightBg: '#ede9fe'
    },
    braces: {
      id: 'braces',
      name: 'Braces',
      color: '#0d9488', // Teal
      bg: '#f0fdfa',
      text: '#0f766e',
      border: '#0d9488',
      lightBg: '#ccfbf1'
    }
  };

  function getTreatmentTheme(treatmentId, details) {
    let key = (treatmentId || '').toLowerCase().trim();
    if (!TREATMENT_THEMES[key]) {
      const det = (details || '').toLowerCase();
      if (det.includes('brace')) key = 'braces';
      else if (det.includes('extract') || det.includes('cabut')) key = 'extraction';
      else if (det.includes('whiten')) key = 'whitening';
      else if (det.includes('crown') || det.includes('bridge')) key = 'crowns_bridges';
      else if (det.includes('veneer')) key = 'veneers';
      else if (det.includes('scali') || det.includes('polish')) key = 'scaling';
      else if (det.includes('fill') || det.includes('tampal') || det.includes('inlay')) key = 'filling';
      else if (det.includes('check') || det.includes('consult')) key = 'checkup';
      else if (det.includes('surg') || det.includes('mos') || det.includes('implant') || det.includes('excision') || det.includes('root') || det.includes('operculectomy')) key = 'mos';
    }
    return TREATMENT_THEMES[key] || {
      id: 'checkup',
      name: 'Check-up',
      color: '#22c55e',
      bg: '#f0fdf4',
      text: '#15803d',
      border: '#22c55e',
      lightBg: '#dcfce7'
    };
  }

  let currentDate = utils.todayDate ? new Date(utils.todayDate()) : new Date();
  let currentView = 'day'; // 'day' | 'week'
  let selectedSlotTime = null;
  let editingAppointmentId = null;
  let currentStatusFilter = 'All';
  let currentSearchQuery = '';

  function parseTimeHHMM(t) {
    if (!t) return 0;
    const parts = t.split(':');
    const h = parseInt(parts[0], 10) || 0;
    const m = parseInt(parts[1], 10) || 0;
    return h * 60 + m;
  }

  function formatTimeHHMM(minsTotal) {
    const h = Math.floor(minsTotal / 60) % 24;
    const m = minsTotal % 60;
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  }

  function getSlotList() {
    const slots = [];
    let t = parseTimeHHMM(CLINIC_START);
    const endT = parseTimeHHMM(CLINIC_END);
    // Slots run up to 30 mins before closing time so appointments end by CLINIC_END
    while (t < endT) {
      slots.push(formatTimeHHMM(t));
      t += SLOT_INTERVAL_MIN;
    }
    return slots;
  }

  function getApptRange(appt) {
    const start = parseTimeHHMM(appt.time);
    let end;
    if (appt.endTime) {
      end = parseTimeHHMM(appt.endTime);
    } else {
      let dur = SLOT_INTERVAL_MIN;
      if (Clinic.TREATMENTS) {
        const tr = Clinic.TREATMENTS.find(t => t.id === appt.treatmentId);
        if (tr && tr.duration) dur = tr.duration;
      }
      end = start + dur;
    }
    return { start, end };
  }

  function isSlotPast(slotTime, dateISO) {
    const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';
    if (!dateISO) return false;
    if (dateISO < todayISO) return true; // Entire past day has passed
    if (dateISO > todayISO) return false; // Future day
    // For today:
    const now = new Date();
    const [sh, sm] = slotTime.split(':').map((x) => parseInt(x, 10));
    // A slot is only considered past when its 30-minute duration is over
    const slotEndDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), sh, sm + SLOT_INTERVAL_MIN, 0, 0);
    return slotEndDate <= now;
  }

  function getAppointmentsForDate(dateISO) {
    if (!dateISO) return [];
    // Strict Sunday Closure: No appointments can ever exist or display on Sundays
    const d = new Date(dateISO + 'T00:00:00');
    if (d.getDay() === 0) {
      return [];
    }

    const list = Clinic.APPOINTMENTS || [];
    const result = [];
    for (let i = 0; i < list.length; i++) {
      if (list[i].dateISO === dateISO) {
        result.push(list[i]);
      }
    }
    return result;
  }

  function findAppointmentAt(dateISO, slotTime) {
    const appts = getAppointmentsForDate(dateISO);
    for (let i = 0; i < appts.length; i++) {
      if (appts[i].time === slotTime) return appts[i];
    }
    return null;
  }

  function findAppointmentCovering(dateISO, slotTime) {
    const appts = getAppointmentsForDate(dateISO);
    const slotStart = parseTimeHHMM(slotTime);
    const slotEnd = slotStart + SLOT_INTERVAL_MIN;
    for (let i = 0; i < appts.length; i++) {
      if (appts[i].statusPill === 'Canceled') continue;
      const range = getApptRange(appts[i]);
      if (range.start < slotEnd && range.end > slotStart) {
        return appts[i];
      }
    }
    return null;
  }

  /**
   * Returns true only if the appointment is genuinely "in progress" right now.
   * Conditions:
   *  1. The appointment date is today.
   *  2. The current clock time is within [appt.time, appt.endTime).
   *  3. The status is NOT Waiting, Completed, or Canceled
   *     (those statuses mean it hasn't started yet or is already done).
   */
  function isAppointmentActiveNow(appt, dateISO) {
    const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';
    if (dateISO !== todayISO) return false; // only possible on today
    if (!appt) return false;

    const badStatuses = ['Waiting', 'Completed', 'Canceled'];
    if (badStatuses.includes(appt.statusPill)) return false;

    const now = new Date();
    const currentMins = now.getHours() * 60 + now.getMinutes();
    const range = getApptRange(appt);
    return currentMins >= range.start && currentMins < range.end;
  }

  function isBufferSlot(dateISO, slotTime) {
    const appts = getAppointmentsForDate(dateISO);
    const slotStart = parseTimeHHMM(slotTime);
    const slotEnd = slotStart + SLOT_INTERVAL_MIN;
    for (let i = 0; i < appts.length; i++) {
      if (appts[i].statusPill === 'Canceled') continue;
      const range = getApptRange(appts[i]);
      const bufStart = range.end;
      const bufEnd = range.end + BUFFER_MIN;
      if ((slotStart >= bufStart && slotStart < bufEnd) || (bufStart >= slotStart && bufStart < slotEnd)) {
        return true;
      }
    }
    return false;
  }

  function getBufferInfoForSlot(dateISO, slotTime) {
    const appts = getAppointmentsForDate(dateISO);
    const slotStart = parseTimeHHMM(slotTime);
    const slotEnd = slotStart + SLOT_INTERVAL_MIN;
    for (let i = 0; i < appts.length; i++) {
      if (appts[i].statusPill === 'Canceled') continue;
      const range = getApptRange(appts[i]);
      // If appointment ends on a slot boundary (e.g. 09:30, 10:00), the turnaround completes within turnover; next slot is clean
      if (range.end % SLOT_INTERVAL_MIN === 0) continue;
      const bufStart = range.end;
      const bufEnd = range.end + BUFFER_MIN;
      if ((slotStart >= bufStart && slotStart < bufEnd) || (bufStart >= slotStart && bufStart < slotEnd)) {
        return {
          active: true,
          range: formatTimeHHMM(bufStart) + '–' + formatTimeHHMM(bufEnd),
          bufStart: bufStart,
          bufEnd: bufEnd,
          appt: appts[i]
        };
      }
    }
    return { active: false };
  }

  function updateAppointmentById(id, updatedData) {
    if (!Clinic.APPOINTMENTS) return;
    for (let i = 0; i < Clinic.APPOINTMENTS.length; i++) {
      if (Clinic.APPOINTMENTS[i].id === id) {
        Object.assign(Clinic.APPOINTMENTS[i], updatedData);
        Clinic.APPOINTMENTS[i].id = id; // Preserve original ID
        if (app.persistAppointments) app.persistAppointments();
        break;
      }
    }
  }

  function hasConflictAtSubmit(dateISO, slotTime, phone, ignoreId = null, durationMin = 30) {
    const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';

    // 0a. Check Sunday Closure
    const targetDayOfWeek = new Date(dateISO + 'T00:00:00').getDay();
    if (targetDayOfWeek === 0) {
      return {
        has: true,
        reason: 'The clinic is closed on Sundays. Operating hours are Monday to Saturday, 9:00 AM – 5:00 PM.'
      };
    }

    // 0b. Check Past Date & Time
    if (dateISO < todayISO) {
      return {
        has: true,
        reason: 'Cannot book or reschedule an appointment for a past date (' + dateISO + ').'
      };
    }
    if (dateISO === todayISO && isSlotPast(slotTime, dateISO)) {
      return {
        has: true,
        reason: 'The selected time slot (' + slotTime + ') has already passed for today.'
      };
    }

    const reqStart = parseTimeHHMM(slotTime);
    const reqEnd = reqStart + durationMin;
    const clinicClose = parseTimeHHMM(CLINIC_END);

    // 0c. Check Dentist Scheduled Leave
    try {
      const rawLeave = localStorage.getItem('kpst.v1.dentist_leave');
      if (rawLeave) {
        const leaveList = JSON.parse(rawLeave);
        const matchLeave = leaveList.find(l => l.date === dateISO);
        if (matchLeave) {
          return {
            has: true,
            reason: `Dr. Zarith Sofia is on scheduled leave on ${dateISO} (${matchLeave.reason}). Bookings cannot be accepted on this date.`
          };
        }
      }
    } catch (e) { /* ignore */ }

    // 1. Clinic closing boundary (17:00 / 5:00 PM)
    if (reqEnd > clinicClose) {
      return { has: true, reason: 'Appointment duration extends beyond clinic closing time (05:00 PM / 17:00).' };
    }

    // 2. Clinic rest break (13:00 - 14:00 / 1:00 PM - 2:00 PM)
    const breakStart = parseTimeHHMM('13:00');
    const breakEnd = parseTimeHHMM('14:00');
    if (reqStart < breakEnd && reqEnd > breakStart) {
      return { has: true, reason: 'Appointment time conflicts with clinic rest break (01:00 PM – 02:00 PM).' };
    }

    // 3. Overlap check with active bookings on this date
    const appts = getAppointmentsForDate(dateISO);
    for (let i = 0; i < appts.length; i++) {
      if (appts[i].id === ignoreId || appts[i].statusPill === 'Canceled') continue;
      const range = getApptRange(appts[i]);
      if (range.start < reqEnd && range.end > reqStart) {
        return {
          has: true,
          reason: 'Slot overlaps with existing booking for ' + (appts[i].patientName || 'another patient') + ' (' + formatTimeHHMM(range.start) + '–' + formatTimeHHMM(range.end) + ').'
        };
      }
    }

    // 4. Cleaning buffer check
    for (let i = 0; i < appts.length; i++) {
      if (appts[i].id === ignoreId || appts[i].statusPill === 'Canceled') continue;
      const range = getApptRange(appts[i]);
      // If previous appointment ended exactly on a slot boundary, next slot starts cleanly
      if (range.end % SLOT_INTERVAL_MIN === 0) continue;
      const bufStart = range.end;
      const bufEnd = range.end + BUFFER_MIN;
      if (reqStart >= bufStart && reqStart < bufEnd) {
        return {
          has: true,
          reason: 'Slot falls within the 5-minute cleaning buffer following another booking (' + formatTimeHHMM(bufStart) + '–' + formatTimeHHMM(bufEnd) + ').'
        };
      }
    }

    // 5. Same phone within ±60 min
    if (phone) {
      const normalizedPhone = phone.trim().replace(/\s+/g, '');
      for (let i = 0; i < appts.length; i++) {
        if (appts[i].id === ignoreId || appts[i].statusPill === 'Canceled') continue;
        if (appts[i].phone && appts[i].phone.replace(/\s+/g, '') === normalizedPhone) {
          const range = getApptRange(appts[i]);
          const diff = Math.abs(reqStart - range.start);
          if (diff <= 60) {
            return {
              has: true,
              reason: 'Same patient phone already booked that day within ±60 minutes of this time.'
            };
          }
        }
      }
    }

    return { has: false };
  }

  function addAppointment(newAppt) {
    if (!Clinic.APPOINTMENTS) Clinic.APPOINTMENTS = [];
    Clinic.APPOINTMENTS.push(newAppt);
    if (app.persistAppointments) app.persistAppointments();
  }

  function cancelAppointmentById(id) {
    if (!Clinic.APPOINTMENTS) return;
    for (let i = 0; i < Clinic.APPOINTMENTS.length; i++) {
      if (Clinic.APPOINTMENTS[i].id === id) {
        // Non-destructive cancellation: preserves entry for past records and auditing
        Clinic.APPOINTMENTS[i].statusPill = 'Canceled';
        if (app.persistAppointments) app.persistAppointments();
        break;
      }
    }
  }

  function generateId() {
    return 'appt-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
  }

  function renderDateLabel() {
    const label = document.getElementById('dateLabel');
    if (!label) return;
    if (currentView === 'week' && utils.toDateISO) {
      const weekDays = getWeekDays(currentDate);
      const first = weekDays[0];
      const last = weekDays[weekDays.length - 1];
      const fmt = (d) => d.toLocaleDateString('en-MY', { day: 'numeric', month: 'short' });
      label.textContent = fmt(first) + ' – ' + last.toLocaleDateString('en-MY', { day: 'numeric', month: 'short', year: 'numeric' });
    } else if (utils.formatReadableDate) {
      label.textContent = utils.formatReadableDate(currentDate);
    }

    const prev = document.getElementById('prevDay');
    const next = document.getElementById('nextDay');
    if (prev) prev.title = currentView === 'week' ? 'Previous Week' : 'Previous Day';
    if (next) next.title = currentView === 'week' ? 'Next Week' : 'Next Day';
  }

  function renderTreatmentLegend() {
    const list = document.getElementById('treatmentLegend');
    if (!list) return;
    list.innerHTML = '';
    const treatments = Clinic.TREATMENTS || [];
    treatments.forEach(function (t) {
      const li = document.createElement('li');
      li.className = 'd-inline-flex align-items-center gap-1.5 small';
      const chip = document.createElement('span');
      chip.style.display = 'inline-block';
      chip.style.width = '10px';
      chip.style.height = '10px';
      chip.style.borderRadius = '50%';
      chip.style.background = t.color;
      const name = document.createElement('span');
      name.className = 'fw-medium text-dark';
      name.textContent = t.name + (t.duration ? ` (${t.duration}m)` : '');
      li.appendChild(chip);
      li.appendChild(name);
      list.appendChild(li);
    });
  }

  function renderSummary() {
    const list = document.getElementById('summaryList');
    const badge = document.getElementById('appointmentCountBadge');

    const dateISO = utils.toDateISO(currentDate);
    const todayISO = utils.toDateISO(new Date());

    if (badge) {
      if (currentView === 'week') {
        // Count all non-cancelled appointments across the whole week
        const weekDays = getWeekDays(currentDate);
        let weekTotal = 0;
        weekDays.forEach(d => {
          const iso = utils.toDateISO(d);
          weekTotal += getAppointmentsForDate(iso).filter(a => a.statusPill !== 'Canceled').length;
        });
        badge.textContent = weekTotal + ' Appointments This Week';
      } else {
        const isSunday = currentDate.getDay() === 0;
        if (isSunday) {
          badge.textContent = 'Clinic Closed on Sundays';
        } else {
          const appts = getAppointmentsForDate(dateISO);
          let total = appts.length;
          let dayWord = 'Today';
          if (dateISO !== todayISO) {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            if (dateISO === utils.toDateISO(tomorrow)) dayWord = 'Tomorrow';
            else if (dateISO === utils.toDateISO(yesterday)) dayWord = 'Yesterday';
            else dayWord = 'on ' + utils.formatReadableDate(currentDate);
          }
          badge.textContent = total + ' Appointments ' + dayWord;
        }
      }
    }

    const appts = getAppointmentsForDate(dateISO);
    let total = appts.length;

    if (!list) return;

    let pastCompleted = 0;
    let remaining = 0;
    if (dateISO === todayISO) {
      const now = new Date();
      appts.forEach(function (a) {
        const [h, m] = a.time.split(':').map((x) => parseInt(x, 10));
        const slotDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m, 0, 0);
        if (slotDate < now) {
          pastCompleted++;
        } else {
          remaining++;
        }
      });
    } else {
      remaining = total;
      pastCompleted = 0;
    }
    list.innerHTML = '';
    const items = [
      { label: 'Total appointments', value: total },
      { label: 'Past/completed', value: pastCompleted },
      { label: 'Remaining', value: remaining }
    ];
    items.forEach(function (it) {
      const li = document.createElement('li');
      li.className = 'summary-item';
      const lbl = document.createElement('span');
      lbl.textContent = it.label;
      const val = document.createElement('strong');
      val.textContent = it.value;
      li.appendChild(lbl);
      li.appendChild(val);
      list.appendChild(li);
    });
  }

  function getWeekDays(d) {
    const dayOfWeek = d.getDay(); // 0 = Sun, 1 = Mon ...
    const distToMon = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
    const monday = new Date(d);
    monday.setDate(d.getDate() + distToMon);

    const days = [];
    for (let i = 0; i < 6; i++) { // Mon to Sat
      const day = new Date(monday);
      day.setDate(monday.getDate() + i);
      days.push(day);
    }
    return days;
  }

  function updateTopLiveClock() {
    const el = document.getElementById('topLiveTimeDisplay');
    if (!el) return;
    const now = new Date();
    const nowH = now.getHours();
    const nowM = now.getMinutes();
    const now12 = nowH % 12 || 12;
    const nowAmpm = nowH >= 12 ? 'PM' : 'AM';
    el.textContent = `${String(now12).padStart(2, '0')}:${String(nowM).padStart(2, '0')} ${nowAmpm}`;
  }

  function renderGrid() {
    updateTopLiveClock();
    const table = document.getElementById('slotTable');
    if (!table) return;
    table.innerHTML = '';

    // Keep datePicker in sync
    const datePicker = document.getElementById('datePickerInput');
    if (datePicker && utils.toDateISO) {
      datePicker.value = utils.toDateISO(currentDate);
    }

    if (currentView === 'week') {
      renderWeekGrid(table);
    } else {
      renderDayGrid(table);
    }
    renderSummary();
  }

  function renderWeekGrid(table) {
    const weekDays = getWeekDays(currentDate);
    const container = document.createElement('div');
    container.className = 'week-view-grid';

    const columnsContainer = document.createElement('div');
    columnsContainer.className = 'week-columns-container';

    weekDays.forEach(day => {
      const dateISO = utils.toDateISO(day);
      const isSelectedDay = dateISO === utils.toDateISO(currentDate);
      const todayISO = utils.toDateISO(new Date());
      const isToday = dateISO === todayISO;
      const isPastDay = dateISO < todayISO;

      const dayName = day.toLocaleDateString('en-MY', { weekday: 'short' });
      const dayNum = day.getDate();
      const monthName = day.toLocaleDateString('en-MY', { month: 'short' });

      const allDayAppts = getAppointmentsForDate(dateISO).filter(a => a.statusPill !== 'Canceled');
      const activeApptCount = allDayAppts.length;

      // Check if dentist is on leave
      let leaveReason = null;
      try {
        if (window.Clinic && window.Clinic.getLeaveReasonForDate) {
          leaveReason = window.Clinic.getLeaveReasonForDate(dateISO);
        }
      } catch (err) {
        leaveReason = null;
      }

      const col = document.createElement('div');
      col.className = 'week-day-col' + (isPastDay ? ' past-day' : '');

      // Day Header (Click to drill into Day view)
      const header = document.createElement('div');
      header.className = `week-day-header ${isSelectedDay ? 'selected' : ''} ${isToday ? 'today' : ''} ${isPastDay ? 'past' : ''}`;
      header.setAttribute('role', 'button');
      header.setAttribute('tabindex', '0');
      header.setAttribute('title', `Click to view full Day schedule for ${dayName}, ${dayNum} ${monthName}`);
      header.innerHTML = `
        <div class="d-flex justify-content-between align-items-center">
          <span class="day-name">${dayName}</span>
          ${isToday ? '<span class="badge text-white" style="background-color: var(--primary-teal); font-size: 0.6rem; padding: 2px 6px;">TODAY</span>' : (isPastDay ? '<span class="badge bg-secondary text-white" style="font-size: 0.6rem; padding: 2px 5px;">PAST</span>' : '')}
        </div>
        <div class="day-date">${dayNum} ${monthName}</div>
        <div class="day-count-badge">${activeApptCount} appointment${activeApptCount === 1 ? '' : 's'}</div>
      `;

      function switchToDay() {
        currentDate = new Date(day);
        currentView = 'day';
        const dayBtn = document.getElementById('dayViewBtn');
        const weekBtn = document.getElementById('weekViewBtn');
        if (dayBtn) dayBtn.classList.add('active');
        if (weekBtn) weekBtn.classList.remove('active');
        renderDateLabel();
        renderGrid();
      }

      header.addEventListener('click', switchToDay);
      header.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          switchToDay();
        }
      });
      col.appendChild(header);

      // Leave Notice if dentist on leave on this day
      if (leaveReason) {
        const leaveBanner = document.createElement('div');
        leaveBanner.className = 'alert alert-danger py-1 px-2 mb-2 text-center rounded-2 small';
        leaveBanner.style.fontSize = '0.72rem';
        leaveBanner.innerHTML = `<i class="bi bi-calendar-x me-1"></i> Dentist on Leave`;
        leaveBanner.title = 'Scheduled leave: ' + leaveReason;
        col.appendChild(leaveBanner);
      }

      // Column Body
      const body = document.createElement('div');
      body.className = 'week-day-body';

      if (allDayAppts.length === 0) {
        body.innerHTML = `
          <div class="text-center text-muted small py-4 my-auto">
            <i class="bi bi-calendar-check d-block fs-3 mb-1 opacity-50"></i>
            <span>No bookings</span>
          </div>
        `;
      } else {
        allDayAppts.sort((a, b) => parseTimeHHMM(a.time) - parseTimeHHMM(b.time));
        allDayAppts.forEach(appt => {
          const treatTheme = getTreatmentTheme(appt.treatmentId, appt.details);
          const isOngoing = isAppointmentActiveNow(appt, dateISO);

          let statusBadgeStyle = 'background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd;'; // Scheduled
          if (appt.statusPill === 'Waiting') {
            statusBadgeStyle = 'background: #fef3c7; color: #92400e; border: 1px solid #fde68a;'; // Waiting
          } else if (appt.statusPill === 'Completed') {
            statusBadgeStyle = 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;'; // Completed
          }

          // Search & Filter support
          let isOpaque = false;
          let isHighlighted = false;
          if (currentStatusFilter !== 'All' && appt.statusPill !== currentStatusFilter) {
            isOpaque = true;
          }
          if (currentSearchQuery && currentSearchQuery.trim() !== '') {
            const query = currentSearchQuery.toLowerCase().trim();
            const patientName = (appt.patientName || '').toLowerCase();
            if (!patientName.includes(query)) {
              isOpaque = true;
            } else {
              isHighlighted = true;
            }
          }

          const card = document.createElement('div');
          card.className = 'week-appt-card shadow-xs' + (isOngoing ? ' in-progress-card' : '');
          card.style.backgroundColor = treatTheme.bg;
          card.style.borderLeft = `3px solid ${isOngoing ? '#0d9488' : treatTheme.border}`;
          card.setAttribute('tabindex', '0');
          card.setAttribute('role', 'button');
          card.setAttribute('aria-label', `Appointment for ${appt.patientName} at ${appt.time}`);

          if (isOpaque) {
            card.style.opacity = '0.3';
          } else if (isHighlighted) {
            card.style.boxShadow = `0 0 10px ${treatTheme.border}88`;
            card.style.transform = 'scale(1.02)';
          }

          card.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-1">
              <span class="badge bg-white text-dark border" style="font-size: 0.65rem;">
                <i class="bi bi-clock me-1"></i>${appt.time}${appt.endTime ? ' - ' + appt.endTime : ''}
              </span>
              <span class="badge text-white" style="background: ${treatTheme.border}; font-size: 0.6rem;">${appt.dentistInitials || 'DZ'}</span>
            </div>
            <div class="d-flex align-items-center gap-1 mb-1">
              ${isOngoing ? '<span class="badge in-progress-badge text-white d-inline-flex align-items-center gap-1 shadow-xs" style="background: #0d9488; font-size: 0.6rem; padding: 1px 6px; border-radius: 4px; font-weight: 600;"><span class="live-dot-pulse"></span> In Progress</span>' : `<span class="badge" style="${statusBadgeStyle} font-size: 0.6rem; padding: 1px 5px;">${app.escapeHtml(appt.statusPill || 'Booked')}</span>`}
              <span class="badge text-white" style="background: ${treatTheme.border}; font-size: 0.6rem; padding: 1px 5px;">${app.escapeHtml(treatTheme.name)}</span>
            </div>
            <div class="fw-bold text-dark text-truncate" style="font-size: 0.82rem;" title="${app.escapeHtml(appt.patientName)}">${app.escapeHtml(appt.patientName)}</div>
            <div class="text-truncate text-muted" style="font-size: 0.7rem;">${app.escapeHtml(appt.details || appt.phone || '')}</div>
          `;

          card.addEventListener('click', (e) => {
            e.stopPropagation();
            openDetailPopover(appt);
          });
          card.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              openDetailPopover(appt);
            }
          });
          body.appendChild(card);
        });
      }
      col.appendChild(body);

      // Footer quick booking button
      const footer = document.createElement('div');
      footer.className = 'week-day-footer mt-auto pt-2';

      if (isPastDay) {
        footer.innerHTML = `
          <button type="button" class="btn btn-sm btn-past-slot w-100 py-1" style="font-size: 0.75rem;" disabled title="Cannot add slots for past dates">
            <i class="bi bi-clock-history me-1"></i>Past Date
          </button>
        `;
      } else if (leaveReason) {
        footer.innerHTML = `
          <button type="button" class="btn btn-sm btn-light text-danger w-100 py-1 border-0" style="font-size: 0.75rem; cursor: not-allowed; background-color: #fee2e2;" disabled title="Dentist on scheduled leave: ${app.escapeHtml(leaveReason)}">
            <i class="bi bi-calendar-x me-1"></i>On Leave
          </button>
        `;
      } else {
        const slots = getSlotList();
        const allPassedToday = isToday && slots.every(s => isSlotPast(s, dateISO));
        if (allPassedToday) {
          footer.innerHTML = `
            <button type="button" class="btn btn-sm btn-past-slot w-100 py-1" style="font-size: 0.75rem;" disabled title="Clinic hours ended for today">
              <i class="bi bi-clock-history me-1"></i>Hours Ended
            </button>
          `;
        } else {
          footer.innerHTML = `
            <button type="button" class="btn btn-sm btn-outline-teal w-100 py-1" style="font-size: 0.75rem;">
              <i class="bi bi-plus-lg me-1"></i>Add Slot
            </button>
          `;
          footer.querySelector('button').addEventListener('click', () => {
            currentDate = new Date(day);
            let firstFreeSlot = '09:00';
            for (let i = 0; i < slots.length; i++) {
              const s = slots[i];
              if (!isSlotPast(s, dateISO) && s !== '13:00' && s !== '13:30' && !findAppointmentAt(dateISO, s)) {
                firstFreeSlot = s;
                break;
              }
            }
            openBookingModal(firstFreeSlot, dateISO);
          });
        }
      }
      col.appendChild(footer);

      columnsContainer.appendChild(col);
    });

    container.appendChild(columnsContainer);
    table.appendChild(container);
  }

  function renderDayGrid(table) {
    const dateISO = utils.toDateISO(currentDate);
    const slots = getSlotList();
    const todayISO = utils.toDateISO(new Date());
    const isToday = (dateISO === todayISO);

    // Check if dentist is on scheduled leave for this date
    let scheduledLeaveReason = null;
    try {
      const rawLeave = localStorage.getItem('kpst.v1.dentist_leave');
      if (rawLeave) {
        const leaveList = JSON.parse(rawLeave);
        const matchLeave = leaveList.find(l => l.date === dateISO);
        if (matchLeave) scheduledLeaveReason = matchLeave.reason;
      }
    } catch (e) { /* ignore */ }

    if (scheduledLeaveReason) {
      const leaveBanner = document.createElement('div');
      leaveBanner.className = 'alert alert-warning d-flex align-items-center gap-2 m-3 mb-2 rounded-3';
      leaveBanner.innerHTML = `<i class="bi bi-calendar-x fs-5 text-danger"></i><div><strong>Dr. Zarith Sofia is on scheduled leave:</strong> ${app.escapeHtml(scheduledLeaveReason)}. Regular booking slots are blocked for this date.</div>`;
      table.appendChild(leaveBanner);
    }

    const isPastDate = dateISO < todayISO;
    if (isPastDate) {
      const pastBanner = document.createElement('div');
      pastBanner.className = 'alert alert-secondary d-flex align-items-center gap-2 m-3 mb-2 rounded-3 py-2 px-3 small';
      pastBanner.innerHTML = `<i class="bi bi-clock-history fs-5 text-secondary"></i><div><strong>Viewing Past Schedule:</strong> ${utils.formatReadableDate ? utils.formatReadableDate(currentDate) : dateISO} has passed. Slots cannot be added or booked for past dates.</div>`;
      table.appendChild(pastBanner);
    }

    const isSunday = currentDate.getDay() === 0;
    if (isSunday) {
      const sundayContainer = document.createElement('div');
      sundayContainer.className = 'p-4 m-3';
      sundayContainer.innerHTML = `
        <div class="alert alert-warning d-flex align-items-center gap-3 rounded-4 p-3 mb-4 shadow-xs">
          <i class="bi bi-door-closed fs-2 text-warning"></i>
          <div>
            <h6 class="fw-bold text-dark mb-1">Clinic Closed on Sundays</h6>
            <div class="text-secondary small">Klinik Pergigian Sofea Taman Tas operates Monday to Saturday from 9:00 AM to 5:00 PM (Rest break from 1:00 PM to 2:00 PM).</div>
          </div>
        </div>
        <div class="text-center py-5 bg-light rounded-4 border border-dashed border-slate-300">
          <div class="mb-3">
            <span class="d-inline-flex align-items-center justify-content-center rounded-circle bg-white shadow-xs text-secondary" style="width: 56px; height: 56px;">
              <i class="bi bi-calendar-x fs-3"></i>
            </span>
          </div>
          <h5 class="fw-bold text-dark mb-1">No Booked Appointments on Sunday</h5>
          <p class="text-muted small mb-0">The clinic is closed. Please navigate to Monday through Saturday to view or schedule appointments.</p>
        </div>
      `;
      table.appendChild(sundayContainer);
      return; // Do not render any timeline slot rows or appointment lists on Sunday
    }

    // Identify next appointment for today
    let nextApptId = null;
    if (isToday) {
      const now = new Date();
      const currentMins = now.getHours() * 60 + now.getMinutes();
      const appts = getAppointmentsForDate(dateISO);

      let minDiff = Infinity;
      appts.forEach(a => {
        if (a.statusPill === 'Canceled') return;
        const [h, m] = a.time.split(':');
        const apptMins = parseInt(h, 10) * 60 + parseInt(m, 10);
        if (apptMins >= currentMins && (apptMins - currentMins) < minDiff) {
          minDiff = apptMins - currentMins;
          nextApptId = a.id;
        }
      });
    }

    let scrollTargetElement = null;

    slots.forEach(function (slotTime) {
      const row = document.createElement('div');
      row.className = 'time-slot-row position-relative';
      row.dataset.hour = slotTime.split(':')[0];

      const timeEl = document.createElement('div');
      timeEl.className = 'time-label text-center text-muted fw-medium';
      timeEl.style.fontSize = '0.85rem';

      const [sh, sm] = slotTime.split(':');
      const hour = parseInt(sh, 10);
      const min = parseInt(sm, 10);
      const ampm = hour >= 12 ? 'PM' : 'AM';
      const hour12 = hour % 12 || 12;

      let isOngoingSlot = false;
      if (isToday) {
        const now = new Date();
        const currentMins = now.getHours() * 60 + now.getMinutes();
        const startMins = hour * 60 + min;
        const endMins = startMins + SLOT_INTERVAL_MIN;
        if (currentMins >= startMins && currentMins < endMins) {
          isOngoingSlot = true;
        }
      }

      if (isOngoingSlot) {
        timeEl.classList.remove('text-muted');
        timeEl.style.cssText = 'background: linear-gradient(135deg, #0d9488, #0f766e) !important; color: #ffffff !important; padding: 0.5rem 0.25rem; border-radius: 8px; box-shadow: 0 4px 10px rgba(13, 148, 136, 0.25);';
        timeEl.innerHTML = `<strong style="font-size: 1rem; color: #ffffff;">${String(hour12).padStart(2, '0')}:${sm}</strong><br><span class="badge bg-white rounded-pill mt-1" style="color: #0f766e; font-size: 0.6rem; font-weight: 700; letter-spacing: 0.5px; padding: 1px 6px;">CURRENT</span>`;
        scrollTargetElement = row;
      } else {
        timeEl.innerHTML = `${String(hour12).padStart(2, '0')}:${sm}<br><span style="font-size: 0.75rem;">${ampm}</span>`;
      }

      const cell = document.createElement('div');
      cell.className = 'time-slot-content position-relative';
      cell.dataset.slot = slotTime;

      // Draw modern "Current Time" live indicator if ongoing slot
      if (isOngoingSlot) {
        const now = new Date();
        const currentMins = now.getHours() * 60 + now.getMinutes();
        const slotFraction = (currentMins - (hour * 60 + min)) / SLOT_INTERVAL_MIN;
        const topPct = Math.max(5, Math.min(95, Math.round(slotFraction * 100)));

        const nowH = now.getHours();
        const nowM = now.getMinutes();
        const now12 = nowH % 12 || 12;
        const nowAmpm = nowH >= 12 ? 'PM' : 'AM';
        const liveTimeFormatted = `${String(now12).padStart(2, '0')}:${String(nowM).padStart(2, '0')} ${nowAmpm}`;

        // Stationary badge pinned at the top-center of this active slot box section
        const topSlotBadge = document.createElement('div');
        topSlotBadge.className = 'slot-current-time-badge';
        topSlotBadge.innerHTML = `
          <span class="live-pulse-dot"></span>
          <span>CURRENT TIME • ${liveTimeFormatted}</span>
        `;
        cell.appendChild(topSlotBadge);

        // Moving line indicating exact progress within the slot
        const nowLine = document.createElement('div');
        nowLine.className = 'timeline-now-line';
        nowLine.style.top = `${topPct}%`;
        nowLine.innerHTML = `
          <div class="timeline-live-node" title="Live clock position (${liveTimeFormatted})"></div>
        `;
        cell.appendChild(nowLine);
      }

      // Handle Clinic Break at 13:00 and 13:30 (Rest break 1:00 PM – 2:00 PM)
      if (slotTime === '13:00' || slotTime === '13:30') {
        cell.classList.add('d-flex', 'align-items-center', 'justify-content-center', 'bg-light-subtle');
        cell.innerHTML += '<span class="text-secondary" style="font-size: 0.85rem; font-style: italic;"><i class="bi bi-cup-hot text-warning me-1"></i> Clinic Rest Break (01:00 PM – 02:00 PM)</span>';
      } else {
        const past = isSlotPast(slotTime, dateISO);
        let appt = findAppointmentAt(dateISO, slotTime);

        // Smart Canceled Logic
        if (appt && appt.statusPill === 'Canceled') {
          const now = new Date();
          const currentMins = now.getHours() * 60 + now.getMinutes();
          const startMins = hour * 60 + min;
          if (currentMins < startMins) {
            appt = null; // Hide future canceled appointments from taking slot
          }
        }

        // Check if slot is covered by an ongoing appointment that started earlier
        const coveringAppt = !appt ? findAppointmentCovering(dateISO, slotTime) : null;

        if (appt) {
          const treatTheme = getTreatmentTheme(appt.treatmentId, appt.details);
          const range = getApptRange(appt);
          const isMultiSlot = (range.end - range.start) > SLOT_INTERVAL_MIN;

          const card = document.createElement('div');
          card.className = 'appointment-card' + (isMultiSlot ? ' multi-start' : '');
          card.dataset.apptId = appt.id;
          card.setAttribute('data-styled', 'true');
          card.setAttribute('tabindex', '0');
          card.setAttribute('role', 'button');
          card.setAttribute('aria-label', `Appointment for ${appt.patientName}`);
          
          if (isMultiSlot) {
            cell.classList.add('has-multi-start');
          }

          const isOngoing = isAppointmentActiveNow(appt, dateISO);

          // Match treatment legend color
          card.style.backgroundColor = treatTheme.bg;
          card.style.borderLeft = `4px solid ${isOngoing ? '#0d9488' : treatTheme.border}`;
          if (isOngoing) {
            card.classList.add('in-progress-card');
          }

          // Status badge colors
          let statusBadgeStyle = 'background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd;'; // Scheduled (sky)
          if (appt.statusPill === 'Waiting') {
            statusBadgeStyle = 'background: #fef3c7; color: #92400e; border: 1px solid #fde68a;'; // Waiting (amber)
          } else if (appt.statusPill === 'Completed') {
            statusBadgeStyle = 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;'; // Completed (green)
          } else if (appt.statusPill === 'Canceled') {
            statusBadgeStyle = 'background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca;'; // Canceled (red)
            card.style.opacity = '0.65';
          }

          let isOpaque = false;
          let isHighlighted = false;

          if (currentStatusFilter !== 'All' && appt.statusPill !== currentStatusFilter) {
            isOpaque = true;
          }

          if (currentSearchQuery && currentSearchQuery.trim() !== '') {
            const query = currentSearchQuery.toLowerCase().trim();
            const patientName = (appt.patientName || '').toLowerCase();
            if (!patientName.includes(query)) {
              isOpaque = true;
            } else {
              isHighlighted = true;
            }
          }

          if (isOpaque) {
            card.style.opacity = '0.3';
          } else if (isHighlighted) {
            card.style.boxShadow = `0 0 12px ${treatTheme.border}88`;
            card.style.transform = 'scale(1.02)';
            card.style.transition = 'all 0.2s ease-in-out';
            card.style.zIndex = '10';
            card.style.position = 'relative';
            card.style.border = `2px solid ${treatTheme.border}`;
          }

          card.innerHTML = `
            <div class="d-flex justify-content-between align-items-start h-100">
              <div class="d-flex flex-column justify-content-center h-100">
                <div class="d-flex align-items-center gap-1 mb-1">
                  <span class="badge-status d-inline-block" style="${statusBadgeStyle} font-size: 0.7rem; padding: 2px 8px; border-radius: 4px; font-weight: 600;">${app.escapeHtml(appt.statusPill || 'Booked')}</span>
                  <span class="badge d-inline-block text-white" style="background: ${treatTheme.border}; font-size: 0.65rem; padding: 2px 7px; border-radius: 4px; font-weight: 600;">${app.escapeHtml(treatTheme.name)}</span>
                  ${appt.id === nextApptId ? '<span class="badge ms-1" style="background-color: var(--primary-teal); font-size: 0.65rem; padding: 3px 6px;">Up Next</span>' : ''}
                  ${isOngoing ? '<span class="badge in-progress-badge d-inline-flex align-items-center gap-1 ms-1 text-white shadow-xs" style="background: linear-gradient(135deg, #0d9488, #0f766e); font-size: 0.65rem; padding: 2px 7px; border-radius: 4px; font-weight: 600;"><span class="live-dot-pulse"></span> In Progress</span>' : ''}
                </div>
                <h6 class="mb-0" style="color: #0f172a; font-weight: 700; font-size: 0.95rem;">${app.escapeHtml(appt.patientName)} <span style="font-weight: 400; color: #64748b; font-size: 0.85rem;">(${app.escapeHtml(appt.details || appt.phone)})</span></h6>
                ${appt.notes ? `<div class="text-muted small mt-1"><i class="bi bi-card-text me-1"></i>${app.escapeHtml(appt.notes)}</div>` : ''}
              </div>
              <div class="d-flex align-items-center gap-2 h-100">
                <span class="text-muted" style="font-size: 0.8rem; color: #64748b !important; font-weight: 500;"><i class="bi bi-clock me-1"></i>${appt.time} - ${appt.endTime || 'XX:XX'}</span>
                <div class="dentist-avatar text-white fw-bold d-flex align-items-center justify-content-center" style="background: ${treatTheme.border}; width: 28px; height: 28px; border-radius: 50%; font-size: 0.8rem;" title="${app.escapeHtml(appt.dentistName || 'Assigned Dentist')}">${appt.dentistInitials || 'DZ'}</div>
              </div>
            </div>
          `;

          // Synchronized hover for multi-slot cards
          if (isMultiSlot) {
            card.addEventListener('mouseenter', function () {
              document.querySelectorAll(`.appointment-card[data-appt-id="${appt.id}"]`).forEach(el => el.classList.add('multi-hover'));
            });
            card.addEventListener('mouseleave', function () {
              document.querySelectorAll(`.appointment-card[data-appt-id="${appt.id}"]`).forEach(el => el.classList.remove('multi-hover'));
            });
          }

          card.addEventListener('click', function (e) {
            e.stopPropagation();
            openDetailPopover(appt);
          });
          card.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              openDetailPopover(appt);
            }
          });
          cell.appendChild(card);

        } else if (coveringAppt) {
          // Continuation of a multi-slot appointment (e.g. 60-minute appointment extending into this slot)
          const isOngoing = isAppointmentActiveNow(coveringAppt, dateISO);
          const covTheme = getTreatmentTheme(coveringAppt.treatmentId, coveringAppt.details);
          const covRange = getApptRange(coveringAppt);
          const slotMins = hour * 60 + min;
          const isLastCoveringSlot = (slotMins + SLOT_INTERVAL_MIN >= covRange.end);

          cell.classList.add('has-multi-continuation');
          cell.classList.add(isLastCoveringSlot ? 'has-multi-end' : 'has-multi-middle');

          const continuationCard = document.createElement('div');
          continuationCard.className = 'appointment-card continuation ' + (isLastCoveringSlot ? 'multi-end' : 'multi-middle');
          continuationCard.dataset.apptId = coveringAppt.id;
          continuationCard.style.cssText = `background: ${covTheme.bg}; border-left: 4px solid ${isOngoing ? '#0d9488' : covTheme.border} !important; cursor: pointer; ${isOngoing ? 'box-shadow: 0 0 0 2px rgba(13, 148, 136, 0.25);' : ''}`;
          continuationCard.setAttribute('tabindex', '0');
          continuationCard.setAttribute('role', 'button');
          continuationCard.setAttribute('aria-label', `Continuation of appointment for ${coveringAppt.patientName}`);
          continuationCard.setAttribute('title', `${coveringAppt.patientName} (${coveringAppt.time} – ${coveringAppt.endTime}) — ${covTheme.name}`);

          // Filter & Search support
          let isOpaque = false;
          let isHighlighted = false;
          if (currentStatusFilter !== 'All' && coveringAppt.statusPill !== currentStatusFilter) {
            isOpaque = true;
          }
          if (currentSearchQuery && currentSearchQuery.trim() !== '') {
            const query = currentSearchQuery.toLowerCase().trim();
            const patientName = (coveringAppt.patientName || '').toLowerCase();
            if (!patientName.includes(query)) {
              isOpaque = true;
            } else {
              isHighlighted = true;
            }
          }
          if (isOpaque) {
            continuationCard.style.opacity = '0.3';
          } else if (isHighlighted) {
            continuationCard.style.boxShadow = `0 0 10px ${covTheme.border}88`;
          }

          // Buffer & Completion details inside continuation slot
          if (isLastCoveringSlot && covRange.end < slotMins + SLOT_INTERVAL_MIN) {
            const bufStartStr = formatTimeHHMM(covRange.end);
            const bufEndStr = formatTimeHHMM(covRange.end + BUFFER_MIN);
            continuationCard.innerHTML = `
              <div class="d-flex align-items-center justify-content-between h-100 px-2 py-1 flex-wrap gap-2">
                <div class="d-flex align-items-center gap-2">
                  <span class="badge bg-white text-secondary border shadow-xs d-inline-flex align-items-center" style="font-size: 0.72rem; font-weight: 500;">
                    <i class="bi bi-clock me-1 text-muted"></i>Concludes at ${bufStartStr}
                  </span>
                  <span class="text-muted small text-truncate" style="font-size: 0.8rem; font-weight: 500;">
                    ${app.escapeHtml(coveringAppt.patientName)}
                  </span>
                </div>
                <div class="d-flex align-items-center">
                  <span class="badge d-inline-flex align-items-center gap-1 shadow-xs" style="background: #fef3c7; color: #92400e; border: 1px solid #fde68a; font-size: 0.75rem; padding: 4px 9px; font-weight: 600;">
                    <i class="bi bi-cup-hot text-amber-600"></i> Cleaning buffer ${bufStartStr}–${bufEndStr}
                  </span>
                </div>
              </div>
            `;
          } else {
            continuationCard.innerHTML = `
              <div class="d-flex align-items-center justify-content-between h-100 px-2 py-1">
                <span class="badge bg-white text-secondary border shadow-xs d-inline-flex align-items-center" style="font-size: 0.72rem; font-weight: 500;">
                  <i class="bi bi-clock me-1 text-muted"></i>Continues until ${formatTimeHHMM(covRange.end)}
                </span>
                <span class="text-muted small text-truncate" style="font-size: 0.8rem; font-weight: 500;">
                  Continuation: ${app.escapeHtml(coveringAppt.patientName)}
                </span>
              </div>
            `;
          }

          // Synchronized hover for multi-slot cards
          continuationCard.addEventListener('mouseenter', function () {
            document.querySelectorAll(`.appointment-card[data-appt-id="${coveringAppt.id}"]`).forEach(el => el.classList.add('multi-hover'));
          });
          continuationCard.addEventListener('mouseleave', function () {
            document.querySelectorAll(`.appointment-card[data-appt-id="${coveringAppt.id}"]`).forEach(el => el.classList.remove('multi-hover'));
          });

          continuationCard.addEventListener('click', function (e) {
            e.stopPropagation();
            openDetailPopover(coveringAppt);
          });
          continuationCard.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              openDetailPopover(coveringAppt);
            }
          });
          cell.appendChild(continuationCard);

        } else if (scheduledLeaveReason) {
          cell.classList.add('bg-light', 'text-muted', 'd-flex', 'align-items-center');
          cell.innerHTML += `<span class="small fst-italic text-danger"><i class="bi bi-calendar-x me-1"></i> Dentist on Leave</span>`;
          cell.title = 'Dentist on scheduled leave: ' + scheduledLeaveReason;
        } else if (isSunday) {
          cell.classList.add('bg-light', 'text-muted', 'd-flex', 'align-items-center');
          cell.innerHTML += '<span class="small fst-italic text-secondary"><i class="bi bi-door-closed me-1"></i> Clinic Closed (Sunday)</span>';
          cell.title = 'Clinic is closed on Sundays';
        } else if (past) {
          cell.classList.add('bg-light', 'text-muted', 'd-flex', 'align-items-center');
          cell.innerHTML += '<span class="small fst-italic">Past slot</span>';
          cell.title = 'Time before now — not clickable';
        } else {
            const freeEl = document.createElement('div');
            freeEl.setAttribute('tabindex', '0');
            freeEl.setAttribute('role', 'button');
            freeEl.setAttribute('aria-label', `Free slot at ${slotTime} — click or press Enter to book`);
            freeEl.style.cssText = `opacity:0.4; height:100%; display:flex; align-items:center; cursor:pointer; font-size:0.85rem; ${isOngoingSlot ? 'padding-top: 16px;' : ''}`;
            freeEl.className = 'text-muted hover:text-dark';
            freeEl.textContent = 'Free slot — click to book';
            freeEl.addEventListener('click', function () {
              openBookingModal(slotTime);
            });
            freeEl.addEventListener('keydown', function (e) {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openBookingModal(slotTime);
              }
            });
            cell.appendChild(freeEl);
          }
        }

        row.appendChild(timeEl);
      row.appendChild(cell);
      table.appendChild(row);
    });

    // Auto-scroll to current time once per session/day
    if (scrollTargetElement && !window.__hasScrolledToNow) {
      window.__hasScrolledToNow = true;
      setTimeout(() => {
        scrollTargetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 200);
    }
  }

  function populateTreatmentSelect() {
    const select = document.getElementById('treatmentType');
    if (!select) return;
    // keep placeholder
    select.innerHTML = '<option value="">Select treatment</option>';
    const treatments = Clinic.TREATMENTS || [];
    treatments.forEach(function (t) {
      const opt = document.createElement('option');
      opt.value = t.id;
      opt.textContent = t.duration ? `${t.name} (~${t.duration} min)` : t.name;
      select.appendChild(opt);
    });
  }

  function resetForm() {
    const form = document.getElementById('appointmentForm');
    if (form) form.reset();
    clearFieldErrors();
    const panel = document.getElementById('formErrorPanel');
    if (panel) {
      panel.classList.add('hidden');
      panel.textContent = '';
    }
    selectedSlotTime = null;
    editingAppointmentId = null;
  }

  function clearFieldErrors() {
    const errs = document.querySelectorAll('.field-error');
    errs.forEach(function (el) {
      el.textContent = '';
    });
  }

  function showFieldError(field, msg) {
    const el = document.querySelector('[data-error-for="' + field + '"]');
    if (el) el.textContent = msg || '';
  }

  function showFormError(msg) {
    const panel = document.getElementById('formErrorPanel');
    if (panel) {
      panel.textContent = msg;
      panel.classList.remove('hidden');
    }
  }

  function populateTimeSlots(selectId, dateISO) {
    const select = document.getElementById(selectId);
    if (!select) return;
    select.innerHTML = '';
    const slots = getSlotList();
    const modalDateInput = document.getElementById('modalDate');
    const targetDate = dateISO || (modalDateInput && modalDateInput.value) || utils.toDateISO(currentDate);

    const isSunday = new Date(targetDate + 'T00:00:00').getDay() === 0;
    if (isSunday) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.disabled = true;
      opt.selected = true;
      opt.textContent = 'Clinic Closed on Sundays';
      select.appendChild(opt);
      return;
    }

    slots.forEach(slot => {
      if (slot === '13:00' || slot === '13:30') return;

      const opt = document.createElement('option');
      opt.value = slot;

      if (isSlotPast(slot, targetDate)) {
        opt.disabled = true;
        opt.textContent = `${slot} (Past)`;
      } else {
        opt.textContent = slot;
      }
      select.appendChild(opt);
    });
  }

  let appointmentModalInstance = null;

  function hideModal() {
    if (appointmentModalInstance) {
      appointmentModalInstance.hide();
    } else if (window.bootstrap) {
      const modalEl = document.getElementById('appointmentModal');
      if (modalEl) {
        const modalInstance = bootstrap.Modal.getInstance(modalEl);
        if (modalInstance) modalInstance.hide();
      }
    }
    resetForm();
  }

  function openBookingModal(slotTime, targetDate) {
    const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';
    let bookingDate = targetDate || utils.toDateISO(currentDate);

    // Guard: Prevent booking for past dates
    if (bookingDate < todayISO) {
      bookingDate = todayISO;
    }

    selectedSlotTime = slotTime;
    editingAppointmentId = null;
    populateTreatmentSelect();

    const form = document.getElementById('appointmentForm');
    if (form) {
      form.reset();
      if (form.modalDate) {
        form.modalDate.value = bookingDate;
        form.modalDate.min = todayISO;
      }
    }

    populateTimeSlots('modalTimeSlot', bookingDate);

    const timeSelect = document.getElementById('modalTimeSlot');
    if (timeSelect && slotTime) {
      timeSelect.value = slotTime;
      // If the selected slot is disabled (past), select first enabled option
      if (timeSelect.selectedOptions && timeSelect.selectedOptions[0] && timeSelect.selectedOptions[0].disabled) {
        const firstEnabled = Array.from(timeSelect.options).find(opt => !opt.disabled);
        if (firstEnabled) {
          timeSelect.value = firstEnabled.value;
          selectedSlotTime = firstEnabled.value;
        }
      }
    }

    const modalTitle = document.querySelector('#appointmentModal .modal-title');
    if (modalTitle) modalTitle.innerHTML = '<i class="bi bi-calendar-plus text-teal me-2"></i> Book New Appointment';

    const confirmBtn = document.querySelector('#appointmentModal button[type="submit"]');
    if (confirmBtn) confirmBtn.textContent = 'Confirm Booking';

    if (window.bootstrap) {
      const el = document.getElementById('appointmentModal');
      appointmentModalInstance = bootstrap.Modal.getOrCreateInstance(el);
      appointmentModalInstance.show();
    }
  }

  let currentDetailModal = null;

  function openDetailPopover(appt) {
    if (app.getRole && app.getRole() !== 'admin') return;
    const treatment = app.getTreatmentById ? app.getTreatmentById(appt.treatmentId) : { name: appt.treatmentId };

    // Format display dentist name consistently
    let dentistDisplayName = 'Dr. Zarith Sofia';

    // Set text contents
    document.getElementById('detailPatientName').textContent = appt.patientName || 'Unknown Patient';
    document.getElementById('detailTreatment').textContent = treatment.name || appt.details || 'General Checkup';
    document.getElementById('detailTime').textContent = `${appt.time} - ${appt.endTime || 'XX:XX'}`;
    document.getElementById('detailDentist').textContent = dentistDisplayName;
    document.getElementById('detailLocation').textContent = 'Room 2 - KPSTS Taman Tas';

    const notesEl = document.getElementById('detailNotes');
    if (notesEl) {
      const remarkText = (appt.notes || '').trim();
      if (remarkText) {
        notesEl.textContent = remarkText;
        notesEl.classList.remove('text-muted', 'fst-italic');
        notesEl.classList.add('text-dark');
      } else {
        notesEl.textContent = 'No remarks recorded for this appointment.';
        notesEl.classList.add('text-muted', 'fst-italic');
        notesEl.classList.remove('text-dark');
      }
    }

    const statusEl = document.getElementById('detailStatusPill');
    const headerBg = document.getElementById('detailHeaderBg');

    // Default style
    let bgCol = '#f0fdf4';
    let pillBg = '#166534';
    let pillText = '#ffffff';
    let statusText = appt.statusPill || appt.treatmentId || 'Booked';

    if (appt.statusPill === 'Waiting') {
      bgCol = '#fff7ed'; pillBg = '#c2410c'; pillText = '#ffffff';
    } else if (appt.statusPill === 'Completed') {
      bgCol = '#f8fafc'; pillBg = '#475569'; pillText = '#ffffff';
    } else if (appt.statusPill === 'Canceled') {
      bgCol = '#fef2f2'; pillBg = '#991b1b'; pillText = '#ffffff';
    }

    statusEl.textContent = statusText;
    statusEl.style.backgroundColor = pillBg;
    statusEl.style.color = pillText;
    headerBg.style.backgroundColor = bgCol;

    // Show modal
    if (!currentDetailModal && window.bootstrap) {
      currentDetailModal = new bootstrap.Modal(document.getElementById('appointmentDetailModal'));
    }
    if (currentDetailModal) currentDetailModal.show();

    // Wire up cancel button using customized confirmation modal instead of confirm()
    const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';
    const isPastAppt = appt.dateISO < todayISO;

    const btnCancel = document.getElementById('btnCancelAppt');
    if (btnCancel) {
      if (appt.statusPill === 'Canceled' || appt.statusPill === 'Completed' || isPastAppt) {
        btnCancel.disabled = true;
        if (isPastAppt) btnCancel.title = 'Cannot cancel past appointments';
      } else {
        btnCancel.disabled = false;
        btnCancel.title = 'Cancel this appointment';
        btnCancel.onclick = function () {
          const cancelModalEl = document.getElementById('cancelConfirmModal');
          const cancelMsg = document.getElementById('cancelConfirmMsg');
          const confirmBtn = document.getElementById('confirmCancelBtn');

          if (cancelMsg) {
            cancelMsg.textContent = `Are you sure you want to cancel the appointment for ${appt.patientName} at ${appt.time}? The slot will be freed, and the record will be archived.`;
          }

          if (cancelModalEl && window.bootstrap) {
            const cancelModal = new bootstrap.Modal(cancelModalEl);
            confirmBtn.onclick = function () {
              cancelAppointmentById(appt.id);
              renderGrid();
              if (app.showToast) {
                app.showToast('Appointment canceled — ' + appt.time, 'success');
              }
              cancelModal.hide();
              if (currentDetailModal) currentDetailModal.hide();
            };
            cancelModal.show();
          } else {
            cancelAppointmentById(appt.id);
            renderGrid();
            if (app.showToast) app.showToast('Appointment canceled — ' + appt.time, 'success');
            if (currentDetailModal) currentDetailModal.hide();
          }
        };
      }
    }

    // Wire up reschedule button
    const btnReschedule = document.querySelector('.btn-reschedule');
    if (btnReschedule) {
      const newBtnReschedule = btnReschedule.cloneNode(true);
      btnReschedule.parentNode.replaceChild(newBtnReschedule, btnReschedule);

      if (appt.statusPill === 'Canceled' || appt.statusPill === 'Completed') {
        newBtnReschedule.disabled = true;
      } else {
        newBtnReschedule.disabled = false;
        newBtnReschedule.onclick = function () {
          if (currentDetailModal) currentDetailModal.hide();
          const reschDate = (appt.dateISO && appt.dateISO >= todayISO) ? appt.dateISO : todayISO;
          openBookingModal(appt.time, reschDate);

          editingAppointmentId = appt.id;

          const form = document.getElementById('appointmentForm');
          if (form) {
            form.patientName.value = appt.patientName || '';
            form.phoneNumber.value = appt.phone || '';
            form.treatmentType.value = appt.treatmentId || '';
            if (form.modalDate) {
              form.modalDate.value = reschDate;
              form.modalDate.min = todayISO;
            }
            if (form.modalDentist) {
              form.modalDentist.value = 'Dr. Zarith Sofia';
            }
            if (form.notes) form.notes.value = appt.notes || '';
          }

          const modalTitle = document.querySelector('#appointmentModal .modal-title');
          if (modalTitle) modalTitle.innerHTML = '<i class="bi bi-calendar-event text-teal me-2"></i> Reschedule Appointment';

          const confirmBtn = document.querySelector('#appointmentModal button[type="submit"]');
          if (confirmBtn) confirmBtn.textContent = 'Save Changes';
        };
      }
    }

    // Wire up complete button
    const btnComplete = document.getElementById('btnCompleteAppt');
    if (btnComplete) {
      const newBtnComplete = btnComplete.cloneNode(true);
      btnComplete.parentNode.replaceChild(newBtnComplete, btnComplete);

      if (appt.statusPill === 'Canceled' || appt.statusPill === 'Completed' || isPastAppt) {
        newBtnComplete.disabled = true;
      } else {
        newBtnComplete.disabled = false;
        newBtnComplete.onclick = function () {
          updateAppointmentById(appt.id, { statusPill: 'Completed' });
          renderGrid();
          if (app.showToast) {
            app.showToast('Appointment marked as Completed', 'success');
          }
          if (currentDetailModal) currentDetailModal.hide();
        };
      }
    }
  }

  function validatePhone(phone) {
    if (!phone) return false;
    const v = phone.trim();
    const re1 = /^\+60\s?\d{1,2}-\d{3,4}\s?\d{4}$/;
    const re2 = /^0\d{1,2}-\d{3,4}\s?\d{4}$/;
    return re1.test(v) || re2.test(v);
  }

  function validateAndBook(formData) {
    const panel = document.getElementById('formErrorPanel');
    if (panel) {
      panel.classList.add('hidden');
      panel.textContent = '';
    }

    if (!formData.patientName || formData.patientName.trim().length === 0) {
      showFormError('Patient Name is required.');
      return false;
    }
    if (!formData.phoneNumber || formData.phoneNumber.trim().length === 0) {
      showFormError('Phone Number is required.');
      return false;
    }
    if (!formData.treatmentType) {
      showFormError('Treatment Type is required.');
      return false;
    }

    const dateISO = formData.dateISO || utils.toDateISO(currentDate);
    const slotTime = selectedSlotTime;
    const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';

    if (dateISO < todayISO) {
      showFormError('Cannot book or reschedule an appointment for a past date.');
      return false;
    }
    if (dateISO === todayISO && isSlotPast(slotTime, dateISO)) {
      showFormError('The selected time slot has already passed for today.');
      return false;
    }

    // Calculate duration from treatment type
    let durationMin = SLOT_INTERVAL_MIN;
    if (Clinic.TREATMENTS) {
      const tr = Clinic.TREATMENTS.find(t => t.id === formData.treatmentType);
      if (tr && tr.duration) durationMin = tr.duration;
    }

    const conflict = hasConflictAtSubmit(dateISO, slotTime, null, editingAppointmentId, durationMin);
    if (conflict.has) {
      showFormError(conflict.reason);
      return false;
    }

    const endTime = formatTimeHHMM(parseTimeHHMM(slotTime) + durationMin);

    // Book or Update
    const newAppt = {
      id: editingAppointmentId || generateId(),
      dateISO: dateISO,
      time: slotTime,
      endTime: endTime,
      patientName: formData.patientName.trim(),
      phone: formData.phoneNumber.trim(),
      treatmentId: formData.treatmentType,
      dentistName: formData.dentistName || 'Dr. Zarith Sofia',
      dentistInitials: formData.dentistInitials || 'DZ',
      notes: formData.notes ? formData.notes.trim() : '',
      statusPill: 'Waiting'
    };

    if (editingAppointmentId) {
      updateAppointmentById(editingAppointmentId, newAppt);
    } else {
      addAppointment(newAppt);
    }

    // If date changed to another day, navigate view to that day
    if (dateISO !== utils.toDateISO(currentDate)) {
      const parts = dateISO.split('-');
      currentDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
      renderDateLabel();
    }

    return true;
  }

  function handleFormSubmit(e) {
    e.preventDefault();
    const form = e.target;

    // Update selectedSlotTime based on dropdown selection
    const timeSelect = document.getElementById('modalTimeSlot');
    if (timeSelect && timeSelect.value) {
      selectedSlotTime = timeSelect.value;
    }
    const lastChangedSlot = selectedSlotTime;

    // Capture assigned dentist (Sole dentist: Dr. Zar / DZ)
    const assignedDentist = 'Dr. Zarith Sofia';
    const initials = 'DZ';

    const dateVal = (form.modalDate && form.modalDate.value) ? form.modalDate.value : utils.toDateISO(currentDate);

    const formData = {
      patientName: form.patientName.value,
      phoneNumber: form.phoneNumber.value,
      treatmentType: form.treatmentType.value,
      dateISO: dateVal,
      dentistName: assignedDentist,
      dentistInitials: initials,
      notes: form.notes ? form.notes.value : ''
    };

    if (validateAndBook(formData)) {
      const bookedSlot = lastChangedSlot;
      hideModal();
      renderGrid();
      if (app.showToast) {
        app.showToast('Appointment booked — ' + bookedSlot, 'success');
      }
    }
  }

  function bindEvents() {
    const prev = document.getElementById('prevDay');
    const next = document.getElementById('nextDay');
    const todayBtn = document.getElementById('todayBtn');
    if (prev) {
      prev.addEventListener('click', function () {
        const step = currentView === 'week' ? -7 : -1;
        currentDate = utils.addDays(currentDate, step);
        renderDateLabel();
        renderGrid();
      });
    }
    if (next) {
      next.addEventListener('click', function () {
        const step = currentView === 'week' ? 7 : 1;
        currentDate = utils.addDays(currentDate, step);
        renderDateLabel();
        renderGrid();
      });
    }
    if (todayBtn) {
      todayBtn.addEventListener('click', function () {
        currentDate = utils.todayDate ? new Date(utils.todayDate()) : new Date();
        renderDateLabel();
        renderGrid();
      });
    }

    // Date picker input
    const datePicker = document.getElementById('datePickerInput');
    if (datePicker) {
      datePicker.addEventListener('change', function () {
        if (this.value) {
          const parts = this.value.split('-');
          currentDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
          renderDateLabel();
          renderGrid();
        }
      });
    }

    // Day / Week View Switcher
    const dayBtn = document.getElementById('dayViewBtn');
    const weekBtn = document.getElementById('weekViewBtn');
    if (dayBtn && weekBtn) {
      dayBtn.addEventListener('click', function () {
        currentView = 'day';
        dayBtn.classList.add('active');
        weekBtn.classList.remove('active');
        renderDateLabel();
        renderGrid();
      });
      weekBtn.addEventListener('click', function () {
        currentView = 'week';
        weekBtn.classList.add('active');
        dayBtn.classList.remove('active');
        renderDateLabel();
        renderGrid();
      });
    }

    // Patient Autocomplete from PATIENTS array
    const patientInput = document.getElementById('patientName');
    const phoneInput = document.getElementById('phoneNumber');
    if (patientInput && Clinic.PATIENTS) {
      const datalist = document.getElementById('patientDatalist');
      if (datalist) {
        datalist.innerHTML = '';
        Clinic.PATIENTS.forEach(p => {
          const opt = document.createElement('option');
          opt.value = p.name;
          datalist.appendChild(opt);
        });
      }
      patientInput.addEventListener('input', function () {
        const val = this.value.trim().toLowerCase();
        const matched = Clinic.PATIENTS.find(p => p.name.toLowerCase() === val);
        if (matched && phoneInput) {
          phoneInput.value = matched.phone;
        }
      });
    }

    const filterOpts = document.querySelectorAll('.filter-opt');
    filterOpts.forEach(opt => {
      opt.addEventListener('click', function (e) {
        e.preventDefault();
        currentStatusFilter = this.dataset.status;
        document.getElementById('currentFilterText').textContent = this.textContent;
        renderGrid();
      });
    });

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      searchInput.addEventListener('input', function (e) {
        currentSearchQuery = e.target.value;
        renderGrid();
      });
    }

    const form = document.getElementById('appointmentForm');
    if (form) form.addEventListener('submit', handleFormSubmit);

    // Modal Date picker input min and change handling
    const modalDateInput = document.getElementById('modalDate');
    if (modalDateInput) {
      const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';
      modalDateInput.min = todayISO;
      modalDateInput.addEventListener('change', function () {
        if (this.value && this.value < todayISO) {
          this.value = todayISO;
          if (app.showToast) {
            app.showToast('Cannot select a past date.', 'warning');
          }
        }
        populateTimeSlots('modalTimeSlot', this.value);
      });
    }

    // Make 'New Appointment' button open modal properly
    const mockNewBtn = document.getElementById('mockNewBtn');
    if (mockNewBtn) {
      mockNewBtn.onclick = function () {
        const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';
        let targetDate = utils.toDateISO(currentDate);
        if (targetDate < todayISO) {
          targetDate = todayISO;
        }

        const slots = getSlotList();
        let firstFree = slots[0];
        for (let i = 0; i < slots.length; i++) {
          const s = slots[i];
          const bufferInfo = getBufferInfoForSlot(targetDate, s);
          if (!findAppointmentAt(targetDate, s) && !isSlotPast(s, targetDate) && !bufferInfo.active && s !== '13:00' && s !== '13:30') {
            firstFree = s;
            break;
          }
        }
        openBookingModal(firstFree, targetDate);
      };
    }
  }

  function showTodayStats() {
    const dateISO = utils.toDateISO(currentDate);
    const dayAppts = getAppointmentsForDate(dateISO);

    const total = dayAppts.filter(a => a.statusPill !== 'Canceled').length;
    const completed = dayAppts.filter(a => a.statusPill === 'Completed').length;
    const pending = dayAppts.filter(a => a.statusPill === 'Waiting' || a.statusPill === 'In Consultation' || a.statusPill === 'Scheduled').length;

    // Available clinic slots = 16 slots total (09:00 - 17:00), excluding 13:00-14:00 rest break = 14 working slots * 30 min = 420 min
    let bookedMinutes = 0;
    dayAppts.forEach(a => {
      if (a.statusPill !== 'Canceled') {
        const range = getApptRange(a);
        bookedMinutes += Math.max(30, range.end - range.start);
      }
    });
    const totalWorkingMinutes = 420;
    const utilPct = Math.min(100, Math.round((bookedMinutes / totalWorkingMinutes) * 100));

    const statTotalEl = document.getElementById('statTotalCount');
    const statCompEl = document.getElementById('statCompletedCount');
    const statPendEl = document.getElementById('statPendingCount');
    const progressEl = document.querySelector('#analyticsModal .progress-bar');
    const utilLabelEl = document.getElementById('utilizationRateLabel');

    if (statTotalEl) statTotalEl.textContent = total;
    if (statCompEl) statCompEl.textContent = completed;
    if (statPendEl) statPendEl.textContent = pending;
    if (progressEl) {
      progressEl.style.width = utilPct + '%';
      progressEl.textContent = utilPct + '%';
    }
    if (utilLabelEl) {
      utilLabelEl.textContent = `${utilPct}% (${bookedMinutes} / ${totalWorkingMinutes} mins)`;
    }

    if (window.bootstrap) {
      const modal = new bootstrap.Modal(document.getElementById('analyticsModal'));
      modal.show();
    }
  }

  window.showTodayStats = showTodayStats;

  function init() {
    const allowed = app.enforceRole ? app.enforceRole(['admin'], function () {
      const denied = document.getElementById('accessDenied');
      const dashboard = document.getElementById('dashboard');
      if (denied) denied.classList.remove('hidden');
      if (dashboard) dashboard.classList.add('hidden');
      if (app.initRoleBadge) app.initRoleBadge();
      if (app.initLogout) app.initLogout();
      if (app.initBackToIndex) app.initBackToIndex();
    }) : true;
    if (!allowed) return;
    const dashboard = document.getElementById('dashboard');
    if (dashboard) dashboard.classList.remove('hidden');
    if (app.initRoleBadge) app.initRoleBadge();
    if (app.initLogout) app.initLogout();
    if (app.initBackToIndex) app.initBackToIndex();
    renderDateLabel();
    renderTreatmentLegend();
    renderGrid();
    bindEvents();
    populateTreatmentSelect();
    updateTopLiveClock();

    // Periodic refresh: every 10s for the top live clock & every 60s to advance the live timeline marker
    setInterval(updateTopLiveClock, 10000);
    setInterval(function () {
      const todayISO = utils.toDateISO ? utils.toDateISO(new Date()) : '';
      const currentISO = utils.toDateISO ? utils.toDateISO(currentDate) : '';
      if (todayISO === currentISO && currentView === 'day') {
        renderGrid();
      }
    }, 60000);
  }

  document.addEventListener('DOMContentLoaded', init);
})(window);
