document.addEventListener('DOMContentLoaded', function () {
  let selectedRole = sessionStorage.getItem('selectedRole') || 'admin';

  const roleBtns = document.querySelectorAll('.role-btn');
  const usernameInput = document.getElementById('usernameInput');
  const passwordInput = document.getElementById('passwordInput');
  const loginError = document.getElementById('loginError');

  function applyRoleUI(role) {
    selectedRole = role;
    sessionStorage.setItem('selectedRole', role);

    roleBtns.forEach(b => {
      if (b.getAttribute('data-role') === role) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });

    if (role === 'admin') {
      usernameInput.value = 'admin';
      passwordInput.value = 'admin123';
    } else {
      usernameInput.value = 'drzar';
      passwordInput.value = 'doctor123';
    }

    if (loginError) loginError.classList.add('d-none');
  }

  // Set initial role state
  applyRoleUI(selectedRole);

  roleBtns.forEach(btn => {
    btn.addEventListener('click', function () {
      const role = this.getAttribute('data-role');
      applyRoleUI(role);
    });
  });

  // Form submission logic with strict credential validation
  const loginForm = document.getElementById('loginForm');
  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();

    const username = usernameInput.value.trim().toLowerCase();
    const password = passwordInput.value.trim();

    if (loginError) loginError.classList.add('d-none');

    if (selectedRole === 'admin') {
      if (username === 'admin' && password === 'admin123') {
        if (window.Clinic && window.Clinic.app && window.Clinic.app.setRole) {
          window.Clinic.app.setRole('admin');
        }
        window.location.href = 'front-desk.html';
      } else {
        showError('Invalid Admin credentials. Please check your username and password.');
      }
    } else if (selectedRole === 'dentist') {
      if ((username === 'drzar' || username === 'doctor') && password === 'doctor123') {
        if (window.Clinic && window.Clinic.app && window.Clinic.app.setRole) {
          window.Clinic.app.setRole('dentist');
        }
        window.location.href = 'home-dentist.html';
      } else {
        showError('Invalid Dentist credentials. Please check your username and password.');
      }
    }
  });

  function showError(msg) {
    if (loginError) {
      loginError.textContent = msg;
      loginError.classList.remove('d-none');
    }
  }

  // ------------------------------------------------------------
  // Interactive Cursor-Reactive Background & Card Spotlight
  // ------------------------------------------------------------
  const spotlight = document.getElementById('cursorSpotlight');
  const orb1 = document.getElementById('orb1');
  const orb2 = document.getElementById('orb2');
  const orb3 = document.getElementById('orb3');
  const loginCard = document.querySelector('.login-card');

  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;
  let currentX = mouseX;
  let currentY = mouseY;
  let isMouseActive = false;

  window.addEventListener('pointermove', function (e) {
    mouseX = e.clientX;
    mouseY = e.clientY;

    if (!isMouseActive && spotlight) {
      isMouseActive = true;
      spotlight.style.opacity = '1';
    }

    // Dynamic specular sheen tracking on the card border
    if (loginCard) {
      const rect = loginCard.getBoundingClientRect();
      const cardX = e.clientX - rect.left;
      const cardY = e.clientY - rect.top;
      loginCard.style.setProperty('--mouse-x', `${cardX}px`);
      loginCard.style.setProperty('--mouse-y', `${cardY}px`);
    }
  });

  window.addEventListener('mouseleave', function () {
    if (spotlight) {
      spotlight.style.opacity = '0';
      isMouseActive = false;
    }
  });

  // Smooth liquid 60fps LERP animation loop
  function renderCursorReactivity() {
    currentX += (mouseX - currentX) * 0.08;
    currentY += (mouseY - currentY) * 0.08;

    if (spotlight) {
      spotlight.style.transform = `translate3d(${currentX}px, ${currentY}px, 0) translate(-50%, -50%)`;
    }

    // Subtle 3D parallax on background orbs based on cursor position
    const normX = (currentX / window.innerWidth) - 0.5;
    const normY = (currentY / window.innerHeight) - 0.5;

    if (orb1) {
      orb1.style.setProperty('--parallax-x', `${normX * 60}px`);
      orb1.style.setProperty('--parallax-y', `${normY * 60}px`);
    }
    if (orb2) {
      orb2.style.setProperty('--parallax-x', `${-normX * 75}px`);
      orb2.style.setProperty('--parallax-y', `${-normY * 55}px`);
    }
    if (orb3) {
      orb3.style.setProperty('--parallax-x', `${normX * 45}px`);
      orb3.style.setProperty('--parallax-y', `${-normY * 40}px`);
    }

    requestAnimationFrame(renderCursorReactivity);
  }
  requestAnimationFrame(renderCursorReactivity);
});
