/**
 * Dentist Management Controller - Klinik Pergigian Sofea
 * Enables admin staff to view, manage, edit, and add doctor profiles in the clinic roster.
 * Features: Multi-dentist management, Photo upload, MDC/APC license validity tracking,
 * One-Click APC License Renewal Enhancement, and real-time roster search & filtering.
 */

document.addEventListener('DOMContentLoaded', function () {
  // Role verification & system hooks
  if (window.Clinic && window.Clinic.app) {
    if (window.Clinic.app.enforceRole && !window.Clinic.app.enforceRole(['admin'])) return;
    if (window.Clinic.app.initRoleBadge) window.Clinic.app.initRoleBadge();
    if (window.Clinic.app.initLogout) window.Clinic.app.initLogout();
  }

  const STORAGE_KEY = 'kpst.v1.dentist_directory';
  const PROFILE_STORAGE_KEY = 'kpst.v1.dentist_profile';
  const AVATAR_STORAGE_KEY = 'dentist_avatar';
  const DEFAULT_AVATAR = 'assets/images/default-profile.jpg';

  // Seed default dentists if directory doesn't exist
  const DEFAULT_DENTISTS = [
    {
      id: 'DZ',
      fullName: 'Dr. Zarul Ikhwan',
      displayName: 'Dr. Zar',
      role: 'Orthodontics & General Specialist',
      specialtyCategory: 'Orthodontics',
      room: 'Room 2',
      email: 'dr.zar@kliniksofea.com',
      phone: '+60 12-345 6789',
      license: 'MDC-2018-4921',
      licenseStart: '2026-01-01',
      licenseExpiry: '2026-12-31',
      joinDate: '2019-10-15',
      experience: '10 Years',
      description: 'Lead dental specialist with over 10 years of experience in orthodontics and general dentistry.',
      status: 'active',
      avatar: 'assets/images/default-profile.jpg',
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
      isPrimary: true
    },
    {
      id: 'DF',
      fullName: 'Dr. Farhana binti Rahman',
      displayName: 'Dr. Farhana',
      role: 'Pediatric Dentistry Specialist',
      specialtyCategory: 'Pediatric',
      room: 'Room 1',
      email: 'dr.farhana@kliniksofea.com',
      phone: '+60 17-882 3411',
      license: 'MDC-2020-6184',
      licenseStart: '2026-01-01',
      licenseExpiry: '2026-11-15',
      joinDate: '2021-03-01',
      experience: '6 Years',
      description: "Specializes in gentle pediatric dental care, early orthodontic interventions, and children's cavity prevention.",
      status: 'active',
      avatar: 'assets/images/default-profile.jpg',
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
      isPrimary: false
    },
    {
      id: 'DK',
      fullName: 'Dr. Kevin Tan Siew Meng',
      displayName: 'Dr. Kevin',
      role: 'Endodontist & Oral Surgeon',
      specialtyCategory: 'Endodontics',
      room: 'Room 3',
      email: 'dr.kevin@kliniksofea.com',
      phone: '+60 13-921 5567',
      license: 'MDC-2016-3392',
      licenseStart: '2026-03-01',
      licenseExpiry: '2027-02-28',
      joinDate: '2018-07-10',
      experience: '12 Years',
      description: 'Expert in complex root canal therapy, surgical extractions, dental implants, and trauma management.',
      status: 'active',
      avatar: 'assets/images/default-profile.jpg',
      days: ['Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
      isPrimary: false
    },
    {
      id: 'DA',
      fullName: 'Dr. Nurul Aina binti Zulkifli',
      displayName: 'Dr. Aina',
      role: 'Aesthetic & Restorative Dentist',
      specialtyCategory: 'Aesthetic',
      room: 'Room 4',
      email: 'dr.aina@kliniksofea.com',
      phone: '+60 19-450 1289',
      license: 'MDC-2022-8710',
      licenseStart: '2025-10-01',
      licenseExpiry: '2026-09-30',
      joinDate: '2023-01-15',
      experience: '4 Years',
      description: 'Focuses on cosmetic smile makeovers, porcelain veneers, composite bonding, and teeth whitening.',
      status: 'on_leave',
      avatar: 'assets/images/default-profile.jpg',
      days: ['Mon', 'Wed', 'Thu', 'Fri', 'Sat'],
      isPrimary: false
    }
  ];

  // Global State
  let dentists = [];
  let editingDentistId = null;
  let renewingDentistId = null;
  let modalPendingAvatar = null;
  let addPendingAvatar = null;

  // DOM Elements
  const gridEl = document.getElementById('dentistsGrid');
  const emptyStateEl = document.getElementById('emptyState');
  const searchInput = document.getElementById('dentistSearchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');
  const specialtyFilter = document.getElementById('specialtyFilter');
  const statusFilter = document.getElementById('statusFilter');
  const resetFiltersBtn = document.getElementById('resetFiltersBtn');
  const addNewDentistBtn = document.getElementById('addNewDentistBtn');

  // KPI elements
  const kpiTotalEl = document.getElementById('kpiTotalDentists');
  const kpiActiveEl = document.getElementById('kpiActiveDentists');
  const kpiOnLeaveEl = document.getElementById('kpiOnLeaveDentists');
  const kpiLicenseEl = document.getElementById('kpiLicenseStatus');

  // Edit Modal Elements
  const editModalEl = document.getElementById('manageDentistModal');
  const editModal = editModalEl ? new bootstrap.Modal(editModalEl) : null;
  const editForm = document.getElementById('manageDentistForm');
  const editAvatarImg = document.getElementById('editModalAvatar');
  const editAvatarUpload = document.getElementById('editModalAvatarUpload');
  const editRemoveAvatarBtn = document.getElementById('editModalRemoveAvatarBtn');
  const editPhoneCodeSelect = document.getElementById('editPhoneCode');
  const editPhoneInput = document.getElementById('editPhone');
  const editApcStartInput = document.getElementById('editApcStart');
  const editApcExpiryInput = document.getElementById('editApcExpiry');
  const editApcCountdown = document.getElementById('editApcCountdown');
  const editDeleteBtn = document.getElementById('editModalDeleteBtn');
  const editModalRenewBtn = document.getElementById('editModalRenewBtn');
  const editExperienceSelect = document.getElementById('editExperience');
  const editJoinDateInput = document.getElementById('editJoinDate');

  // Add Modal Elements
  const addModalEl = document.getElementById('addDentistModal');
  const addModal = addModalEl ? new bootstrap.Modal(addModalEl) : null;
  const addForm = document.getElementById('addDentistForm');
  const addAvatarImg = document.getElementById('addModalAvatar');
  const addAvatarUpload = document.getElementById('addModalAvatarUpload');
  const addRemoveAvatarBtn = document.getElementById('addModalRemoveAvatarBtn');
  const addPhoneCodeSelect = document.getElementById('addPhoneCode');
  const addPhoneInput = document.getElementById('addPhone');
  const addApcStartInput = document.getElementById('addApcStart');
  const addApcExpiryInput = document.getElementById('addApcExpiry');
  const addApcCountdown = document.getElementById('addApcCountdown');
  const addExperienceSelect = document.getElementById('addExperience');
  const addJoinDateInput = document.getElementById('addJoinDate');

  // License Renewal Modal Elements
  const renewModalEl = document.getElementById('renewLicenseModal');
  const renewModal = renewModalEl ? new bootstrap.Modal(renewModalEl) : null;
  const renewForm = document.getElementById('renewLicenseForm');
  const renewDocAvatar = document.getElementById('renewDocAvatar');
  const renewDocName = document.getElementById('renewDocName');
  const renewDocRole = document.getElementById('renewDocRole');
  const renewDocMdc = document.getElementById('renewDocMdc');
  const renewCurrentExpiry = document.getElementById('renewCurrentExpiry');
  const renewCurrentCountdown = document.getElementById('renewCurrentCountdown');
  const renewNewExpiryPreview = document.getElementById('renewNewExpiryPreview');
  const renewNewCountdownPreview = document.getElementById('renewNewCountdownPreview');
  const renewTermSelect = document.getElementById('renewTermSelect');
  const renewCustomDateGroup = document.getElementById('renewCustomDateGroup');
  const renewCustomStart = document.getElementById('renewCustomStart');
  const renewCustomExpiry = document.getElementById('renewCustomExpiry');

  // Helper: Toast notification
  function notify(title, message, type) {
    if (window.Clinic && window.Clinic.app && window.Clinic.app.showToast) {
      window.Clinic.app.showToast(title, message, type);
    }
  }

  // Helper: Malaysian Phone Number Formatter (auto-spaces as user types: e.g. 12-345 6789 or 11-1234 5678)
  function formatMalaysianPhone(val) {
    if (!val) return '';
    let digits = String(val).replace(/\D/g, '');

    // Strip leading 60 if user typed or pasted country code
    if (digits.startsWith('60')) {
      digits = digits.slice(2);
    }
    // Strip leading 0 if user typed trunk prefix 012...
    if (digits.startsWith('0')) {
      digits = digits.slice(1);
    }

    // Cap at 10 digits
    digits = digits.slice(0, 10);
    if (!digits) return '';

    // 011 prefix (8 digits after 11) -> 11-XXXX XXXX
    if (digits.startsWith('11')) {
      if (digits.length <= 2) return digits;
      if (digits.length <= 6) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
      return `${digits.slice(0, 2)}-${digits.slice(2, 6)} ${digits.slice(6)}`;
    }

    // Standard 2-digit prefix (10, 12, 13, 14, 15, 16, 17, 18, 19, etc.)
    if (digits.length <= 2) return digits;
    if (digits.length <= 5) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
    if (digits.length > 9) {
      return `${digits.slice(0, 2)}-${digits.slice(2, 6)} ${digits.slice(6)}`;
    }
    // Standard 7-digit subscriber -> 12-345 6789
    return `${digits.slice(0, 2)}-${digits.slice(2, 5)} ${digits.slice(5)}`;
  }

  // Helper: Phone number parser (standardized to Malaysia +60)
  function parsePhoneNumber(phoneStr) {
    if (!phoneStr) return { code: '+60', number: '' };
    const str = String(phoneStr).trim();
    let num = str;
    if (num.startsWith('+60')) {
      num = num.slice(3).trim();
    } else if (num.startsWith('60')) {
      num = num.slice(2).trim();
    } else if (num.startsWith('0')) {
      num = num.replace(/^0+/, '').trim();
    }
    return { code: '+60', number: formatMalaysianPhone(num) };
  }

  // Helper: Attach live auto-formatting listener to phone inputs
  function attachPhoneAutoFormat(inputEl) {
    if (!inputEl) return;
    inputEl.addEventListener('input', function () {
      this.value = formatMalaysianPhone(this.value);
    });
  }

  // Helper: Format date to short readable string (e.g. 31 Dec 2026)
  function formatDateShort(dateStr) {
    if (!dateStr) return 'N/A';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-MY', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  // Helper: Convert any date representation to YYYY-MM-DD
  function toISODate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  // Helper: Downsample image using HTML5 Canvas to max 300x300 JPEG
  function downsampleImage(file, maxSize = 300, quality = 0.85) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = function (e) {
        const img = new Image();
        img.onload = function () {
          let width = img.width;
          let height = img.height;
          if (width > height) {
            if (width > maxSize) {
              height = Math.round((height * maxSize) / width);
              width = maxSize;
            }
          } else {
            if (height > maxSize) {
              width = Math.round((width * maxSize) / height);
              height = maxSize;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  // 1. Data Persistence: Load & Save
  function loadDentists() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        dentists = JSON.parse(raw);
        // Ensure default fields exist
        dentists.forEach(d => {
          if (!d.licenseStart) {
            const expYear = d.licenseExpiry ? new Date(d.licenseExpiry).getFullYear() : 2026;
            d.licenseStart = `${expYear}-01-01`;
          }
          if (d.joinDate && d.joinDate.includes(',')) {
            d.joinDate = toISODate(d.joinDate);
          }
        });
      } else {
        dentists = JSON.parse(JSON.stringify(DEFAULT_DENTISTS));
      }

      // Synchronize Dr. Zar's profile if it was edited elsewhere
      const zarIndex = dentists.findIndex(d => d.id === 'DZ');
      if (zarIndex !== -1) {
        const zarProfileRaw = localStorage.getItem(PROFILE_STORAGE_KEY);
        const zarAvatarRaw = localStorage.getItem(AVATAR_STORAGE_KEY);
        if (zarProfileRaw) {
          try {
            const zarData = JSON.parse(zarProfileRaw);
            if (zarData.fullName) dentists[zarIndex].fullName = zarData.fullName;
            if (zarData.displayName) dentists[zarIndex].displayName = zarData.displayName;
            if (zarData.email) dentists[zarIndex].email = zarData.email;
            if (zarData.phone) dentists[zarIndex].phone = zarData.phone;
            if (zarData.license) dentists[zarIndex].license = zarData.license;
            if (zarData.licenseStart) dentists[zarIndex].licenseStart = zarData.licenseStart;
            if (zarData.licenseExpiry) dentists[zarIndex].licenseExpiry = zarData.licenseExpiry;
            if (zarData.joinDate) dentists[zarIndex].joinDate = toISODate(zarData.joinDate) || zarData.joinDate;
            if (zarData.experience) dentists[zarIndex].experience = zarData.experience;
          } catch (e) {
            console.warn(e);
          }
        }
        if (zarAvatarRaw) {
          dentists[zarIndex].avatar = zarAvatarRaw;
        }
      }

      saveDentistsToStorage(false);
    } catch (e) {
      console.error('Error loading dentists:', e);
      dentists = JSON.parse(JSON.stringify(DEFAULT_DENTISTS));
    }
  }

  function saveDentistsToStorage(syncDrZar = true) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dentists));

      // Synchronize Dr. Zar's profile if requested
      if (syncDrZar) {
        const zar = dentists.find(d => d.id === 'DZ');
        if (zar) {
          const profileData = {
            fullName: zar.fullName,
            displayName: zar.displayName || zar.fullName,
            role: zar.role,
            description: zar.description || '',
            age: '34 Years',
            email: zar.email,
            phone: zar.phone,
            license: zar.license,
            licenseStart: zar.licenseStart || '2026-01-01',
            licenseExpiry: zar.licenseExpiry,
            joinDate: zar.joinDate,
            experience: zar.experience
          };
          localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profileData));

          if (zar.avatar && zar.avatar.startsWith('data:')) {
            localStorage.setItem(AVATAR_STORAGE_KEY, zar.avatar);
          } else if (zar.avatar === DEFAULT_AVATAR) {
            localStorage.removeItem(AVATAR_STORAGE_KEY);
          }
        }
      }
    } catch (e) {
      console.error('Error saving dentists to storage:', e);
    }
  }

  // 2. License Expiry Calculation
  function calculateLicenseStatus(dateStr) {
    if (!dateStr) {
      return {
        status: 'valid',
        cssClass: 'valid',
        badgeText: 'Active',
        countdownText: 'No expiry set',
        dateFormatted: 'N/A'
      };
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiry = new Date(dateStr);
    expiry.setHours(0, 0, 0, 0);

    const diffMs = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    const formattedDate = expiry.toLocaleDateString('en-MY', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });

    if (diffDays < 0) {
      return {
        status: 'expired',
        cssClass: 'expired',
        badgeText: 'Expired',
        countdownText: `Expired ${Math.abs(diffDays)}d ago`,
        dateFormatted: formattedDate
      };
    } else if (diffDays <= 30) {
      return {
        status: 'warning',
        cssClass: 'warning',
        badgeText: 'Expiring Soon',
        countdownText: `${diffDays} days remaining`,
        dateFormatted: formattedDate
      };
    } else {
      let durationDesc = `${diffDays} days left`;
      if (diffDays > 60) {
        const months = Math.floor(diffDays / 30.4);
        durationDesc = `${diffDays}d (${months}m) left`;
      }
      return {
        status: 'valid',
        cssClass: 'valid',
        badgeText: 'Active',
        countdownText: durationDesc,
        dateFormatted: formattedDate
      };
    }
  }

  function updateLicenseCountdownPreview(el, dateStr) {
    if (!el) return;
    const info = calculateLicenseStatus(dateStr);
    el.className = `license-countdown-preview ${info.cssClass}`;
    el.innerHTML = `<i class="fa-regular fa-clock"></i> <strong>${info.countdownText}</strong> • Valid until ${info.dateFormatted}`;
  }

  // 3. Render KPIs
  function renderKPIs() {
    if (!kpiTotalEl) return;
    const total = dentists.length;
    const active = dentists.filter(d => d.status === 'active').length;
    const onLeave = dentists.filter(d => d.status === 'on_leave').length;

    let hasExpired = false;
    let hasWarning = false;

    dentists.forEach(d => {
      const calc = calculateLicenseStatus(d.licenseExpiry);
      if (calc.status === 'expired') hasExpired = true;
      if (calc.status === 'warning') hasWarning = true;
    });

    kpiTotalEl.textContent = total;
    kpiActiveEl.textContent = active;
    kpiOnLeaveEl.textContent = onLeave;

    if (hasExpired) {
      kpiLicenseEl.textContent = 'Action Required';
      kpiLicenseEl.style.color = '#dc2626';
    } else if (hasWarning) {
      kpiLicenseEl.textContent = 'Renewal Due Soon';
      kpiLicenseEl.style.color = '#d97706';
    } else {
      kpiLicenseEl.textContent = '100% Up to Date';
      kpiLicenseEl.style.color = '#059669';
    }
  }

  // 4. Render Dentist Cards Roster
  function renderRoster() {
    if (!gridEl) return;

    const searchTerm = (searchInput ? searchInput.value.trim().toLowerCase() : '');
    const selectedSpecialty = (specialtyFilter ? specialtyFilter.value : '');
    const selectedStatus = (statusFilter ? statusFilter.value : '');

    if (clearSearchBtn) {
      if (searchTerm.length > 0) {
        clearSearchBtn.classList.remove('d-none');
      } else {
        clearSearchBtn.classList.add('d-none');
      }
    }

    const filtered = dentists.filter(doc => {
      const matchSearch =
        !searchTerm ||
        doc.fullName.toLowerCase().includes(searchTerm) ||
        (doc.displayName && doc.displayName.toLowerCase().includes(searchTerm)) ||
        doc.role.toLowerCase().includes(searchTerm) ||
        doc.email.toLowerCase().includes(searchTerm) ||
        doc.license.toLowerCase().includes(searchTerm) ||
        doc.room.toLowerCase().includes(searchTerm);

      const matchSpecialty =
        !selectedSpecialty ||
        (doc.specialtyCategory && doc.specialtyCategory.toLowerCase() === selectedSpecialty.toLowerCase()) ||
        doc.role.toLowerCase().includes(selectedSpecialty.toLowerCase());

      const matchStatus = !selectedStatus || doc.status === selectedStatus;

      return matchSearch && matchSpecialty && matchStatus;
    });

    if (filtered.length === 0) {
      gridEl.innerHTML = '';
      if (emptyStateEl) emptyStateEl.classList.remove('d-none');
      return;
    }

    if (emptyStateEl) emptyStateEl.classList.add('d-none');

    const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    gridEl.innerHTML = filtered.map(doc => {
      const licenseInfo = calculateLicenseStatus(doc.licenseExpiry);
      const statusLabel = doc.status === 'active' ? 'Active' : doc.status === 'on_leave' ? 'On Leave' : 'Inactive';
      const statusIcon = doc.status === 'active' ? 'bi-check-circle-fill' : doc.status === 'on_leave' ? 'bi-clock-fill' : 'bi-dash-circle-fill';

      const daysMarkup = WEEKDAYS.map(day => {
        const isActiveDay = doc.days && doc.days.includes(day);
        return `<span class="day-chip ${isActiveDay ? 'active' : ''}">${day}</span>`;
      }).join('');

      const licenseStartFormatted = formatDateShort(doc.licenseStart || '2026-01-01');
      const licenseExpiryFormatted = formatDateShort(doc.licenseExpiry);

      return `
        <div class="col-12 col-md-6 col-xxl-3">
          <div class="doctor-card" data-doctor-id="${doc.id}">
            <!-- Header -->
            <div class="doctor-card-header">
              <div class="doctor-avatar-container">
                <img src="${doc.avatar || DEFAULT_AVATAR}" alt="${doc.fullName}" class="doctor-avatar-img" onerror="this.src='${DEFAULT_AVATAR}'">
                <span class="doctor-status-dot ${doc.status}" title="Status: ${statusLabel}"></span>
              </div>
              <div class="doctor-primary-info">
                <div class="doctor-name-row">
                  <h3 class="doctor-full-name" title="${doc.fullName}">${doc.fullName}</h3>
                </div>
                <div class="d-flex align-items-center mb-1">
                  <span class="doctor-status-pill ${doc.status}">
                    <i class="bi ${statusIcon}"></i> ${statusLabel}
                  </span>
                </div>
                <span class="doctor-role-badge" title="${doc.role}">${doc.role}</span>
              </div>
            </div>

            <!-- Body Details -->
            <div class="doctor-card-body">
              <div class="d-flex justify-content-between align-items-center gap-2">
                <span class="doctor-room-badge">
                  <i class="bi bi-door-closed text-slate-400"></i> ${doc.room || 'General Room'}
                </span>
                <span class="doctor-experience-tag" title="Clinical Experience: ${doc.experience || 'Specialist'}">
                  <i class="bi bi-award text-slate-400 me-1"></i> ${doc.experience || 'Specialist'}
                </span>
              </div>

              <div class="doctor-meta-row">
                <i class="bi bi-envelope"></i>
                <a href="mailto:${doc.email}" class="meta-value text-decoration-none text-slate-700 hover:text-teal">${doc.email}</a>
              </div>

              <div class="doctor-meta-row">
                <i class="bi bi-telephone"></i>
                <span class="meta-value text-slate-700">${doc.phone}</span>
              </div>

              <!-- MDC & APC License Container with Start & Expiry Dates and One-Click Renew -->
              <div class="doctor-license-box">
                <div class="license-row-header">
                  <span>MDC License</span>
                  <span>APC Validity Range</span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1">
                  <span class="license-mdc-code">${doc.license}</span>
                  <span class="license-date-range">
                    ${licenseStartFormatted} &mdash; ${licenseExpiryFormatted}
                  </span>
                </div>
                <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-1">
                  <span class="license-expiry-pill ${licenseInfo.cssClass}" title="APC valid until ${licenseInfo.dateFormatted}">
                    <i class="fa-regular fa-clock"></i> ${licenseInfo.countdownText}
                  </span>
                  <button type="button" class="btn-renew-apc" data-action="renew-license" data-id="${doc.id}" title="One-Click APC Renewal Confirmation">
                    <i class="bi bi-arrow-repeat"></i> Renew APC
                  </button>
                </div>
              </div>

              <!-- Working Days Schedule -->
              <div>
                <div style="font-size: 0.72rem; color: #64748b; font-weight: 600; text-transform: uppercase; margin-bottom: 0.2rem;">
                  Duty Schedule
                </div>
                <div class="working-days-list">
                  ${daysMarkup}
                </div>
              </div>
            </div>

            <!-- Footer Actions -->
            <div class="doctor-card-footer">
              <button type="button" class="btn-manage-doctor" data-action="manage" data-id="${doc.id}">
                <i class="bi bi-sliders"></i> Manage Profile
              </button>

              <button type="button" class="btn-doctor-quick-action" data-action="toggle-status" data-id="${doc.id}" title="Toggle Active / On Leave">
                <i class="bi bi-arrow-repeat"></i>
              </button>

              <button type="button" class="btn-doctor-quick-action btn-doctor-delete" data-action="delete" data-id="${doc.id}" title="Remove Doctor">
                <i class="bi bi-trash3"></i>
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    attachCardActionListeners();
  }

  // 5. Card Action Handlers
  function attachCardActionListeners() {
    document.querySelectorAll('[data-action="manage"]').forEach(btn => {
      btn.addEventListener('click', function () {
        const docId = this.getAttribute('data-id');
        openManageModal(docId);
      });
    });

    document.querySelectorAll('[data-action="renew-license"]').forEach(btn => {
      btn.addEventListener('click', function () {
        const docId = this.getAttribute('data-id');
        openRenewModal(docId);
      });
    });

    document.querySelectorAll('[data-action="toggle-status"]').forEach(btn => {
      btn.addEventListener('click', function () {
        const docId = this.getAttribute('data-id');
        toggleDoctorStatus(docId);
      });
    });

    document.querySelectorAll('[data-action="delete"]').forEach(btn => {
      btn.addEventListener('click', function () {
        const docId = this.getAttribute('data-id');
        deleteDoctor(docId);
      });
    });
  }

  function toggleDoctorStatus(docId) {
    const doc = dentists.find(d => d.id === docId);
    if (!doc) return;

    if (doc.status === 'active') {
      doc.status = 'on_leave';
      notify('Status Updated', `${doc.displayName || doc.fullName} is now set to On Leave.`, 'info');
    } else {
      doc.status = 'active';
      notify('Status Updated', `${doc.displayName || doc.fullName} is now Active on duty.`, 'success');
    }

    saveDentistsToStorage(doc.id === 'DZ');
    renderKPIs();
    renderRoster();
  }

  function deleteDoctor(docId) {
    const doc = dentists.find(d => d.id === docId);
    if (!doc) return;

    if (confirm(`Are you sure you want to remove ${doc.fullName} from the clinic dentist registry?`)) {
      dentists = dentists.filter(d => d.id !== docId);
      saveDentistsToStorage(docId === 'DZ');
      renderKPIs();
      renderRoster();
      notify('Dentist Removed', `${doc.fullName} has been removed from the registry.`, 'info');
    }
  }

  // 6. Manage Doctor Profile Modal
  function openManageModal(docId) {
    const doc = dentists.find(d => d.id === docId);
    if (!doc || !editModal) return;

    editingDentistId = docId;
    modalPendingAvatar = null;

    // Set Avatar
    if (editAvatarImg) {
      editAvatarImg.src = doc.avatar || DEFAULT_AVATAR;
      editAvatarImg.onerror = () => { editAvatarImg.src = DEFAULT_AVATAR; };
    }

    // Set text inputs
    document.getElementById('editModalDoctorNameTitle').textContent = doc.fullName;
    document.getElementById('editFullName').value = doc.fullName || '';
    document.getElementById('editDisplayName').value = doc.displayName || '';
    document.getElementById('editRole').value = doc.role || '';
    document.getElementById('editSpecialtyCategory').value = doc.specialtyCategory || 'General';
    document.getElementById('editRoom').value = doc.room || 'Room 1';
    document.getElementById('editStatus').value = doc.status || 'active';
    document.getElementById('editEmail').value = doc.email || '';

    // Phone Country Code + Number
    const phoneParsed = parsePhoneNumber(doc.phone);
    if (editPhoneCodeSelect) editPhoneCodeSelect.value = phoneParsed.code;
    if (editPhoneInput) editPhoneInput.value = phoneParsed.number;

    // Regulatory & APC Dates
    document.getElementById('editLicense').value = doc.license || '';
    if (editApcStartInput) editApcStartInput.value = toISODate(doc.licenseStart) || `${new Date().getFullYear()}-01-01`;
    if (editApcExpiryInput) editApcExpiryInput.value = toISODate(doc.licenseExpiry) || `${new Date().getFullYear()}-12-31`;

    // Clinical Experience via Select
    if (editExperienceSelect) {
      const expVal = (doc.experience || '').trim();
      let matched = false;
      for (const opt of editExperienceSelect.options) {
        if (opt.value === expVal || expVal.startsWith(opt.value)) {
          editExperienceSelect.value = opt.value;
          matched = true;
          break;
        }
      }
      if (!matched) {
        const match = expVal.match(/\d+/);
        if (match) {
          const num = parseInt(match[0], 10);
          if (num >= 20) editExperienceSelect.value = '20+ Years';
          else if (num >= 15) editExperienceSelect.value = '15 Years';
          else if (num >= 12) editExperienceSelect.value = '12 Years';
          else if (num >= 10) editExperienceSelect.value = '10 Years';
          else editExperienceSelect.value = `${num} Year${num > 1 ? 's' : ''}`;
        } else {
          editExperienceSelect.value = '5 Years';
        }
      }
    }

    // Join Date via calendar date picker
    if (editJoinDateInput) {
      editJoinDateInput.value = toISODate(doc.joinDate);
    }

    // Set weekday checkboxes
    const dayCheckboxes = document.querySelectorAll('#editModalWeekdayGroup input[type="checkbox"]');
    dayCheckboxes.forEach(cb => {
      cb.checked = doc.days ? doc.days.includes(cb.value) : false;
    });

    // Update countdown preview
    updateLicenseCountdownPreview(editApcCountdown, doc.licenseExpiry || '2026-12-31');

    // Show delete button inside modal for all doctors
    if (editDeleteBtn) {
      editDeleteBtn.classList.remove('d-none');
    }

    editModal.show();
  }

  // Live auto-format for Malaysian phone numbers
  if (editPhoneInput) attachPhoneAutoFormat(editPhoneInput);
  if (addPhoneInput) attachPhoneAutoFormat(addPhoneInput);

  // Live input listener for edit modal license expiry
  if (editApcExpiryInput) {
    editApcExpiryInput.addEventListener('input', function () {
      updateLicenseCountdownPreview(editApcCountdown, this.value);
    });
  }

  // Quick Renew button inside edit modal opens the One-Click Renewal confirmation
  if (editModalRenewBtn) {
    editModalRenewBtn.addEventListener('click', function () {
      if (!editingDentistId) return;
      openRenewModal(editingDentistId);
    });
  }

  // Edit Avatar file upload preview
  if (editAvatarUpload && editAvatarImg) {
    editAvatarUpload.addEventListener('change', async function (e) {
      if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        if (!file.type.startsWith('image/')) {
          notify('Invalid File', 'Please select a valid image file.', 'error');
          return;
        }
        try {
          const base64 = await downsampleImage(file, 300, 0.85);
          editAvatarImg.src = base64;
          modalPendingAvatar = base64;
          notify('Photo Selected', 'Preview updated. Click "Save Profile" to apply.', 'info');
        } catch (err) {
          notify('Upload Error', 'Could not process image.', 'error');
        }
      }
    });
  }

  // Edit Avatar remove button
  if (editRemoveAvatarBtn && editAvatarImg) {
    editRemoveAvatarBtn.addEventListener('click', function (e) {
      e.preventDefault();
      editAvatarImg.src = DEFAULT_AVATAR;
      modalPendingAvatar = 'default';
      if (editAvatarUpload) editAvatarUpload.value = '';
      notify('Photo Reset', 'Avatar preview reset to default.', 'info');
    });
  }

  // Edit Form Submit
  if (editForm) {
    editForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!editingDentistId) return;

      const docIndex = dentists.findIndex(d => d.id === editingDentistId);
      if (docIndex === -1) return;

      const fullNameVal = document.getElementById('editFullName').value.trim();
      const emailVal = document.getElementById('editEmail').value.trim();
      const phoneCodeVal = editPhoneCodeSelect ? editPhoneCodeSelect.value : '+60';
      const phoneNumVal = editPhoneInput ? editPhoneInput.value.trim() : '';

      // Basic validation
      if (!fullNameVal) {
        notify('Missing Name', 'Please provide the doctor full name.', 'error');
        return;
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        notify('Invalid Email', 'Please provide a valid doctor email address.', 'error');
        return;
      }
      if (!phoneNumVal) {
        notify('Invalid Phone', 'Please provide a doctor phone number.', 'error');
        return;
      }

      const apcStartVal = editApcStartInput ? editApcStartInput.value : '';
      const apcExpiryVal = editApcExpiryInput ? editApcExpiryInput.value : '';

      if (apcStartVal && apcExpiryVal && new Date(apcStartVal) > new Date(apcExpiryVal)) {
        notify('Invalid Dates', 'APC Start Date cannot be after Expiry Date.', 'error');
        return;
      }

      // Selected days
      const days = [];
      document.querySelectorAll('#editModalWeekdayGroup input[type="checkbox"]:checked').forEach(cb => {
        days.push(cb.value);
      });

      // Update doctor record
      dentists[docIndex].fullName = fullNameVal;
      dentists[docIndex].displayName = document.getElementById('editDisplayName').value.trim() || fullNameVal;
      dentists[docIndex].role = document.getElementById('editRole').value.trim();
      dentists[docIndex].specialtyCategory = document.getElementById('editSpecialtyCategory').value;
      dentists[docIndex].room = document.getElementById('editRoom').value;
      dentists[docIndex].status = document.getElementById('editStatus').value;
      dentists[docIndex].email = emailVal;
      const formattedPhone = formatMalaysianPhone(phoneNumVal);
      dentists[docIndex].phone = `+60 ${formattedPhone}`;
      dentists[docIndex].license = document.getElementById('editLicense').value.trim();
      dentists[docIndex].licenseStart = apcStartVal || '2026-01-01';
      dentists[docIndex].licenseExpiry = apcExpiryVal || '2026-12-31';
      dentists[docIndex].joinDate = editJoinDateInput ? editJoinDateInput.value : '';
      dentists[docIndex].experience = editExperienceSelect ? editExperienceSelect.value : '5 Years';
      dentists[docIndex].days = days;

      // Handle avatar change
      if (modalPendingAvatar === 'default') {
        dentists[docIndex].avatar = DEFAULT_AVATAR;
      } else if (modalPendingAvatar && typeof modalPendingAvatar === 'string') {
        dentists[docIndex].avatar = modalPendingAvatar;
      }

      saveDentistsToStorage(dentists[docIndex].id === 'DZ');
      renderKPIs();
      renderRoster();

      if (editModal) editModal.hide();
      notify('Profile Updated', `${dentists[docIndex].fullName}'s profile was updated successfully.`, 'success');
    });
  }

  // Delete from inside edit modal
  if (editDeleteBtn) {
    editDeleteBtn.addEventListener('click', function () {
      if (!editingDentistId) return;
      if (editModal) editModal.hide();
      deleteDoctor(editingDentistId);
    });
  }

  // 7. Add New Dentist Modal Handlers
  if (addNewDentistBtn && addModal) {
    addNewDentistBtn.addEventListener('click', function () {
      addPendingAvatar = null;
      if (addForm) addForm.reset();
      if (addAvatarImg) addAvatarImg.src = DEFAULT_AVATAR;

      const now = new Date();
      if (addPhoneCodeSelect) addPhoneCodeSelect.value = '+60';
      if (addApcStartInput) addApcStartInput.value = `${now.getFullYear()}-01-01`;
      if (addApcExpiryInput) {
        addApcExpiryInput.value = `${now.getFullYear()}-12-31`;
        updateLicenseCountdownPreview(addApcCountdown, addApcExpiryInput.value);
      }
      if (addJoinDateInput) {
        addJoinDateInput.value = toISODate(now);
      }
      if (addExperienceSelect) {
        addExperienceSelect.value = '5 Years';
      }

      // Check default working days Mon - Fri
      document.querySelectorAll('#addModalWeekdayGroup input[type="checkbox"]').forEach(cb => {
        cb.checked = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].includes(cb.value);
      });

      addModal.show();
    });
  }

  if (addApcExpiryInput) {
    addApcExpiryInput.addEventListener('input', function () {
      updateLicenseCountdownPreview(addApcCountdown, this.value);
    });
  }

  // Add Avatar file upload preview
  if (addAvatarUpload && addAvatarImg) {
    addAvatarUpload.addEventListener('change', async function (e) {
      if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        if (!file.type.startsWith('image/')) {
          notify('Invalid File', 'Please select a valid image file.', 'error');
          return;
        }
        try {
          const base64 = await downsampleImage(file, 300, 0.85);
          addAvatarImg.src = base64;
          addPendingAvatar = base64;
        } catch (err) {
          notify('Upload Error', 'Could not process image.', 'error');
        }
      }
    });
  }

  if (addRemoveAvatarBtn && addAvatarImg) {
    addRemoveAvatarBtn.addEventListener('click', function (e) {
      e.preventDefault();
      addAvatarImg.src = DEFAULT_AVATAR;
      addPendingAvatar = 'default';
      if (addAvatarUpload) addAvatarUpload.value = '';
    });
  }

  // Add Form Submit
  if (addForm) {
    addForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const fullNameVal = document.getElementById('addFullName').value.trim();
      const emailVal = document.getElementById('addEmail').value.trim();
      const phoneCodeVal = addPhoneCodeSelect ? addPhoneCodeSelect.value : '+60';
      const phoneNumVal = addPhoneInput ? addPhoneInput.value.trim() : '';

      if (!fullNameVal) {
        notify('Missing Name', 'Please provide the doctor full name.', 'error');
        return;
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        notify('Invalid Email', 'Please provide a valid doctor email address.', 'error');
        return;
      }
      if (!phoneNumVal) {
        notify('Missing Phone', 'Please provide a doctor phone number.', 'error');
        return;
      }

      const apcStartVal = addApcStartInput ? addApcStartInput.value : '';
      const apcExpiryVal = addApcExpiryInput ? addApcExpiryInput.value : '';

      if (apcStartVal && apcExpiryVal && new Date(apcStartVal) > new Date(apcExpiryVal)) {
        notify('Invalid Dates', 'APC Start Date cannot be after Expiry Date.', 'error');
        return;
      }

      const days = [];
      document.querySelectorAll('#addModalWeekdayGroup input[type="checkbox"]:checked').forEach(cb => {
        days.push(cb.value);
      });

      const uniqueId = 'DOC_' + Date.now().toString(36).toUpperCase();
      const avatarSrc = (addPendingAvatar && addPendingAvatar !== 'default') ? addPendingAvatar : DEFAULT_AVATAR;
      const now = new Date();

      const newDoctor = {
        id: uniqueId,
        fullName: fullNameVal,
        displayName: document.getElementById('addDisplayName').value.trim() || fullNameVal.split(' ')[1] || fullNameVal,
        role: document.getElementById('addRole').value.trim() || 'Dental Practitioner',
        specialtyCategory: document.getElementById('addSpecialtyCategory').value || 'General',
        room: document.getElementById('addRoom').value || 'Room 1',
        status: document.getElementById('addStatus').value || 'active',
        email: emailVal,
        phone: `+60 ${formatMalaysianPhone(phoneNumVal)}`,
        license: document.getElementById('addLicense').value.trim() || 'MDC-' + now.getFullYear() + '-' + Math.floor(1000 + Math.random() * 9000),
        licenseStart: apcStartVal || `${now.getFullYear()}-01-01`,
        licenseExpiry: apcExpiryVal || `${now.getFullYear()}-12-31`,
        joinDate: addJoinDateInput && addJoinDateInput.value ? addJoinDateInput.value : toISODate(now),
        experience: addExperienceSelect ? addExperienceSelect.value : '5 Years',
        avatar: avatarSrc,
        days: days.length > 0 ? days : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        isPrimary: false
      };

      dentists.push(newDoctor);
      saveDentistsToStorage(false);
      renderKPIs();
      renderRoster();

      if (addModal) addModal.hide();
      notify('Dentist Added', `${newDoctor.fullName} was successfully registered into the clinic roster.`, 'success');
    });
  }

  // 8. One-Click License Renewal Enhancement Modal Logic
  function calculateRenewalDates(currentStart, currentExpiry, term) {
    const today = new Date();
    const currExp = currentExpiry ? new Date(currentExpiry) : today;
    const baseYear = !isNaN(currExp.getTime()) ? currExp.getFullYear() : today.getFullYear();

    let newStart = '';
    let newExpiry = '';

    if (term === 'annual_eoy') {
      // Standard Malaysian Dental Council renewal: Annual cycle ending on 31 Dec next calendar year
      const targetYear = baseYear >= today.getFullYear() ? baseYear + 1 : today.getFullYear();
      newStart = `${targetYear}-01-01`;
      newExpiry = `${targetYear}-12-31`;
    } else if (term === 'plus_1_year') {
      const startD = !isNaN(currExp.getTime()) ? new Date(currExp) : new Date(today);
      startD.setDate(startD.getDate() + 1);
      newStart = toISODate(startD);

      const expD = !isNaN(currExp.getTime()) ? new Date(currExp) : new Date(today);
      expD.setFullYear(expD.getFullYear() + 1);
      newExpiry = toISODate(expD);
    } else if (term === 'plus_6_months') {
      const startD = !isNaN(currExp.getTime()) ? new Date(currExp) : new Date(today);
      startD.setDate(startD.getDate() + 1);
      newStart = toISODate(startD);

      const expD = !isNaN(currExp.getTime()) ? new Date(currExp) : new Date(today);
      expD.setMonth(expD.getMonth() + 6);
      newExpiry = toISODate(expD);
    }

    return { newStart, newExpiry };
  }

  function updateRenewalModalPreview() {
    if (!renewingDentistId) return;
    const doc = dentists.find(d => d.id === renewingDentistId);
    if (!doc) return;

    const term = renewTermSelect ? renewTermSelect.value : 'annual_eoy';

    if (term === 'custom') {
      if (renewCustomDateGroup) renewCustomDateGroup.classList.remove('d-none');
      const startVal = renewCustomStart ? renewCustomStart.value : '';
      const expVal = renewCustomExpiry ? renewCustomExpiry.value : '';

      if (expVal) {
        const info = calculateLicenseStatus(expVal);
        renewNewExpiryPreview.textContent = formatDateShort(expVal);
        renewNewCountdownPreview.textContent = `${info.countdownText} (${info.badgeText})`;
        renewNewCountdownPreview.className = `small fw-semibold ${info.status === 'valid' ? 'text-success' : 'text-danger'}`;
      } else {
        renewNewExpiryPreview.textContent = 'Select Date';
        renewNewCountdownPreview.textContent = 'Pending selection';
      }
    } else {
      if (renewCustomDateGroup) renewCustomDateGroup.classList.add('d-none');
      const { newStart, newExpiry } = calculateRenewalDates(doc.licenseStart, doc.licenseExpiry, term);
      const info = calculateLicenseStatus(newExpiry);
      renewNewExpiryPreview.textContent = formatDateShort(newExpiry);
      renewNewCountdownPreview.textContent = `${info.countdownText} (${info.badgeText})`;
      renewNewCountdownPreview.className = `small fw-semibold ${info.status === 'valid' ? 'text-success' : 'text-danger'}`;

      if (renewCustomStart) renewCustomStart.value = newStart;
      if (renewCustomExpiry) renewCustomExpiry.value = newExpiry;
    }
  }

  function openRenewModal(docId) {
    const doc = dentists.find(d => d.id === docId);
    if (!doc || !renewModal) return;

    renewingDentistId = docId;

    if (renewDocAvatar) renewDocAvatar.src = doc.avatar || DEFAULT_AVATAR;
    if (renewDocName) renewDocName.textContent = doc.fullName;
    if (renewDocRole) renewDocRole.textContent = `${doc.role} • ${doc.room || 'General'}`;
    if (renewDocMdc) renewDocMdc.textContent = doc.license || 'MDC-REGISTERED';

    const currentInfo = calculateLicenseStatus(doc.licenseExpiry);
    if (renewCurrentExpiry) renewCurrentExpiry.textContent = formatDateShort(doc.licenseExpiry);
    if (renewCurrentCountdown) {
      renewCurrentCountdown.textContent = `${currentInfo.countdownText} (${currentInfo.badgeText})`;
      renewCurrentCountdown.className = `small ${currentInfo.status === 'valid' ? 'text-muted' : 'text-danger fw-bold'}`;
    }

    if (renewTermSelect) renewTermSelect.value = 'annual_eoy';
    if (renewCustomDateGroup) renewCustomDateGroup.classList.add('d-none');

    updateRenewalModalPreview();
    renewModal.show();
  }

  if (renewTermSelect) {
    renewTermSelect.addEventListener('change', updateRenewalModalPreview);
  }

  if (renewCustomStart) {
    renewCustomStart.addEventListener('input', updateRenewalModalPreview);
  }
  if (renewCustomExpiry) {
    renewCustomExpiry.addEventListener('input', updateRenewalModalPreview);
  }

  if (renewForm) {
    renewForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!renewingDentistId) return;

      const docIndex = dentists.findIndex(d => d.id === renewingDentistId);
      if (docIndex === -1) return;

      const term = renewTermSelect ? renewTermSelect.value : 'annual_eoy';
      let targetStart = '';
      let targetExpiry = '';

      if (term === 'custom') {
        targetStart = renewCustomStart ? renewCustomStart.value : '';
        targetExpiry = renewCustomExpiry ? renewCustomExpiry.value : '';
      } else {
        const res = calculateRenewalDates(dentists[docIndex].licenseStart, dentists[docIndex].licenseExpiry, term);
        targetStart = res.newStart;
        targetExpiry = res.newExpiry;
      }

      if (!targetExpiry) {
        notify('Missing Expiry Date', 'Please choose a valid renewed expiry date.', 'error');
        return;
      }

      if (targetStart && targetExpiry && new Date(targetStart) > new Date(targetExpiry)) {
        notify('Invalid Dates', 'Start date cannot be after expiry date.', 'error');
        return;
      }

      // Update doctor record
      dentists[docIndex].licenseStart = targetStart || dentists[docIndex].licenseStart || '2026-01-01';
      dentists[docIndex].licenseExpiry = targetExpiry;

      saveDentistsToStorage(dentists[docIndex].id === 'DZ');
      renderKPIs();
      renderRoster();

      // If manage profile modal is currently open for this doctor, sync it live!
      if (editingDentistId === renewingDentistId) {
        if (editApcStartInput) editApcStartInput.value = dentists[docIndex].licenseStart;
        if (editApcExpiryInput) editApcExpiryInput.value = dentists[docIndex].licenseExpiry;
        updateLicenseCountdownPreview(editApcCountdown, dentists[docIndex].licenseExpiry);
      }

      if (renewModal) renewModal.hide();
      notify('APC License Renewed', `${dentists[docIndex].fullName}'s practicing certificate was successfully renewed until ${formatDateShort(targetExpiry)}.`, 'success');
    });
  }

  // 9. Search & Filter Listeners
  if (searchInput) {
    searchInput.addEventListener('input', renderRoster);
  }

  if (clearSearchBtn && searchInput) {
    clearSearchBtn.addEventListener('click', function () {
      searchInput.value = '';
      renderRoster();
      searchInput.focus();
    });
  }

  if (specialtyFilter) {
    specialtyFilter.addEventListener('change', renderRoster);
  }

  if (statusFilter) {
    statusFilter.addEventListener('change', renderRoster);
  }

  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener('click', function () {
      if (searchInput) searchInput.value = '';
      if (specialtyFilter) specialtyFilter.value = '';
      if (statusFilter) statusFilter.value = '';
      renderRoster();
    });
  }

  // Initial Load & Render
  loadDentists();
  renderKPIs();
  renderRoster();
});
