/**
 * Dentist Dashboard - Dynamic Real-time Queue & Consultation Progression
 * Klinik Pergigian Sofea Taman Tas
 * 
 * Implements Idea 1: Operating Hours (9:00 AM - 5:00 PM) Awareness
 * with After-Hours & Daily Clinical Wrap-Up Mode
 */

document.addEventListener('DOMContentLoaded', () => {
  if (window.Clinic && window.Clinic.app) {
    if (window.Clinic.app.initRoleBadge) window.Clinic.app.initRoleBadge();
    if (window.Clinic.app.initLogout) window.Clinic.app.initLogout();
    if (window.Clinic.app.enforceRole && !window.Clinic.app.enforceRole(['dentist'])) return;
  }

  initDentistDashboard();
});

let searchQuery = '';

function escapeHtml(str) {
  if (window.Clinic && window.Clinic.app && window.Clinic.app.escapeHtml) {
    return window.Clinic.app.escapeHtml(str);
  }
  return String(str || '').replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function parseTimeHHMM(timeStr) {
  if (!timeStr) return 0;
  const parts = String(timeStr).split(':');
  return (parseInt(parts[0], 10) || 0) * 60 + (parseInt(parts[1], 10) || 0);
}

function formatTime12h(hhmm) {
  if (window.Clinic && window.Clinic.utils && window.Clinic.utils.formatTime12h) {
    return window.Clinic.utils.formatTime12h(hhmm);
  }
  if (!hhmm) return '';
  const parts = hhmm.split(':');
  const h = parseInt(parts[0], 10) || 0;
  const m = parseInt(parts[1], 10) || 0;
  const period = h >= 12 ? 'PM' : 'AM';
  let hour12 = h % 12;
  if (hour12 === 0) hour12 = 12;
  return `${String(hour12).padStart(2, '0')}:${String(m).padStart(2, '0')} ${period}`;
}

/**
 * Operating Hours helper:
 * Clinic operates Mon - Sat from 09:00 to 17:00 (closed on Sundays).
 */
function getClinicOperatingState() {
  const now = new Date();
  const day = now.getDay(); // 0 is Sunday
  const currentMins = now.getHours() * 60 + now.getMinutes();

  const OPEN_MINS = 9 * 60;   // 09:00 AM (540 mins)
  const CLOSE_MINS = 17 * 60; // 05:00 PM (1020 mins)

  const isSunday = (day === 0);
  const isOpen = !isSunday && currentMins >= OPEN_MINS && currentMins < CLOSE_MINS;

  return {
    isOpen: isOpen,
    isSunday: isSunday,
    isAfterHours: !isOpen,
    isBeforeOpen: !isSunday && currentMins < OPEN_MINS,
    isAfterClose: !isSunday && currentMins >= CLOSE_MINS,
    currentMins: currentMins
  };
}

function getTodayAppointmentsForDoctor() {
  if (!window.Clinic || !window.Clinic.APPOINTMENTS) return [];

  const today = window.Clinic.utils ? window.Clinic.utils.todayDate() : new Date();
  if (today.getDay() === 0) return []; // Clinic is closed on Sundays

  const todayISO = window.Clinic.utils ? window.Clinic.utils.toDateISO(today) : today.toISOString().split('T')[0];

  // Primary doctor view: Dr. Zar ('DZ')
  return window.Clinic.APPOINTMENTS.filter(a => {
    return a.dateISO === todayISO && (a.dentistInitials === 'DZ' || !a.dentistInitials);
  });
}

/**
 * Calculates live consultation progression, elapsed minutes, and overrun
 */
function getConsultationTiming(appt) {
  const now = new Date();
  const currentMins = now.getHours() * 60 + now.getMinutes();
  const duration = appt.duration || (window.Clinic && window.Clinic.TREATMENTS && window.Clinic.TREATMENTS[appt.treatmentId]?.duration) || 60;

  // Use consultationStartTime if recorded, otherwise fallback to appointment time
  let startHHMM = appt.consultationStartTime || appt.time || '12:00';
  let startMins = parseTimeHHMM(startHHMM);

  let elapsed = currentMins - startMins;

  // If session appears > 180 min or negative, provide a realistic active duration
  if (elapsed < 0 || elapsed > 180) {
    elapsed = 24;
  }

  const remaining = Math.max(0, duration - elapsed);
  const isOverrun = elapsed > duration;
  const overrunMins = isOverrun ? (elapsed - duration) : 0;

  return {
    startHHMM,
    startTimeFormatted: formatTime12h(startHHMM),
    elapsed,
    remaining,
    duration,
    isOverrun,
    overrunMins
  };
}

/**
 * Determines dynamic real-time status of each appointment in the queue
 */
function getApptRealtimeStatus(appt, clinicState) {
  if (appt.statusPill === 'In Consultation') {
    // If clinic is already closed for the day, active consultation cannot physically be ongoing
    if (clinicState.isAfterHours) {
      return {
        status: 'unclosed',
        badgeText: 'PAST DUE (UNCLOSED)',
        badgeClass: 'text-amber-800 bg-amber-50 border-amber-300 font-bold',
        pillClass: 'bg-amber-500',
        actionType: 'unclosed-actions',
        subtext: 'Scheduled 12:00 PM • Unclosed checkout'
      };
    }

    return {
      status: 'in-session',
      badgeText: 'IN SESSION',
      badgeClass: 'text-blue-700 bg-blue-50 border-blue-200',
      pillClass: 'bg-blue-500',
      actionType: 'complete',
      subtext: 'In Room 2 with Dr. Zar'
    };
  }

  const now = new Date();
  const currentMins = now.getHours() * 60 + now.getMinutes();
  const slotMins = parseTimeHHMM(appt.time);
  const diff = currentMins - slotMins;

  // If clinic is closed for the day
  if (clinicState.isAfterHours) {
    return {
      status: 'unclosed',
      badgeText: 'PAST DUE',
      badgeClass: 'text-amber-800 bg-amber-50 border-amber-300 font-bold',
      pillClass: 'bg-amber-500',
      actionType: 'unclosed-actions',
      subtext: `Slot passed (${formatTime12h(appt.time)})`
    };
  }

  // During operating hours:
  if (diff > 15) {
    const overdueMins = Math.min(diff, 120);
    const overdueText = overdueMins >= 60 
      ? `${Math.floor(overdueMins / 60)}h ${overdueMins % 60}m overdue`
      : `${overdueMins}m overdue`;

    return {
      status: 'overdue',
      badgeText: 'DELAYED',
      badgeClass: 'text-amber-800 bg-amber-50 border-amber-300 font-bold',
      pillClass: 'bg-amber-500',
      actionType: 'call',
      subtext: overdueText
    };
  } else if (Math.abs(diff) <= 15) {
    return {
      status: 'current',
      badgeText: 'READY NOW',
      badgeClass: 'text-emerald-800 bg-emerald-50 border-emerald-300 font-bold',
      pillClass: 'bg-emerald-500',
      actionType: 'call',
      subtext: 'Current slot • In lobby'
    };
  } else {
    const untilMins = Math.abs(diff);
    const untilStr = untilMins >= 60 
      ? `in ${Math.floor(untilMins / 60)}h ${untilMins % 60}m` 
      : `in ${untilMins}m`;

    return {
      status: 'upcoming',
      badgeText: 'UPCOMING',
      badgeClass: 'text-slate-600 bg-slate-100 border-slate-200',
      pillClass: 'bg-slate-400',
      actionType: 'call',
      subtext: untilStr
    };
  }
}

/**
 * Ticks the real-time digital clock in header with clinic status
 */
function updateLiveClock() {
  const clockEl = document.getElementById('liveClockTime');
  const clockBadge = document.getElementById('liveClockBadge');
  const now = new Date();
  const state = getClinicOperatingState();

  const timeFormatted = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });

  if (clockEl) {
    clockEl.textContent = timeFormatted;
  }

  if (clockBadge) {
    if (state.isOpen) {
      clockBadge.innerHTML = `
        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
        <span class="font-mono text-[12px] font-bold" id="liveClockTime">${timeFormatted}</span>
        <span class="text-[10px] text-emerald-600 font-semibold uppercase tracking-wider pl-1 border-l border-slate-200">Live</span>
      `;
      clockBadge.title = 'Clinic Operating Hours (9:00 AM – 5:00 PM)';
    } else {
      const closedLabel = state.isSunday ? 'Sunday' : 'Closed';
      clockBadge.innerHTML = `
        <span class="w-2 h-2 rounded-full bg-amber-400"></span>
        <span class="font-mono text-[12px] font-bold" id="liveClockTime">${timeFormatted}</span>
        <span class="text-[10px] text-amber-600 font-semibold uppercase tracking-wider pl-1 border-l border-slate-200">${closedLabel}</span>
      `;
      clockBadge.title = 'Clinic is currently closed (Operating hours: 9:00 AM – 5:00 PM)';
    }
  }

  const headerDateText = document.getElementById('headerDateText');
  if (headerDateText) {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    headerDateText.textContent = `Here is your daily clinical overview for ${now.toLocaleDateString('en-US', options)}.`;
  }
}

function renderDashboard() {
  // Sync latest appointments from memory/storage
  const allToday = getTodayAppointmentsForDoctor();
  const clinicState = getClinicOperatingState();

  // Filter by search query if typed
  const appts = allToday.filter(a => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    const name = (a.patientName || '').toLowerCase();
    const details = (a.details || a.treatmentId || '').toLowerCase();
    const phone = (a.phone || '').toLowerCase();
    return name.includes(q) || details.includes(q) || phone.includes(q);
  });

  const completed = allToday.filter(a => a.statusPill === 'Completed');
  const pending = allToday.filter(a => a.statusPill !== 'Completed' && a.statusPill !== 'Canceled' && a.statusPill !== 'Cancelled' && a.statusPill !== 'No-Show');
  
  // During daytime hours, in consultation patient
  const inConsult = clinicState.isOpen ? allToday.find(a => a.statusPill === 'In Consultation') : null;

  // Update Stat Counters
  const statTotal = document.getElementById('statTotalPatients');
  const statCompleted = document.getElementById('statCompletedPatients');
  const statPending = document.getElementById('statPendingPatients');
  const statTotalSubtext = document.getElementById('statTotalSubtext');
  const statCompletedSubtext = document.getElementById('statCompletedSubtext');
  const statPendingSubtext = document.getElementById('statPendingSubtext');

  const activeScheduledCount = allToday.filter(a => a.statusPill !== 'Canceled' && a.statusPill !== 'Cancelled' && a.statusPill !== 'No-Show').length;
  const canceledCount = allToday.length - activeScheduledCount;

  if (statTotal) statTotal.textContent = allToday.length;
  if (statTotalSubtext) {
    statTotalSubtext.textContent = canceledCount > 0 
      ? `${activeScheduledCount} Active • ${canceledCount} Canceled` 
      : `Dr. Zar Clinical Schedule`;
  }

  if (statCompleted) statCompleted.textContent = completed.length;
  if (statCompletedSubtext) {
    const pct = activeScheduledCount > 0 ? Math.round((completed.length / activeScheduledCount) * 100) : 0;
    statCompletedSubtext.textContent = `${pct}% completed today`;
  }

  if (statPending) statPending.textContent = pending.length;
  if (statPendingSubtext) {
    if (clinicState.isAfterHours) {
      statPendingSubtext.textContent = pending.length > 0 
        ? `${pending.length} unclosed checkout${pending.length > 1 ? 's' : ''}` 
        : `All procedures closed`;
    } else {
      statPendingSubtext.textContent = inConsult 
        ? `1 in session • ${pending.length - 1} in queue` 
        : `${pending.length} waiting in lobby`;
    }
  }

  // Cards
  const activeCard = document.getElementById('activeConsultationCard');
  const noActiveCard = document.getElementById('noActiveConsultationCard');
  const afterHoursCard = document.getElementById('afterHoursCard');

  // =========================================================================
  // STATE 1: AFTER-HOURS / CLINIC CLOSED (Idea 1)
  // =========================================================================
  if (clinicState.isAfterHours) {
    if (activeCard) activeCard.classList.add('hidden');
    if (noActiveCard) noActiveCard.classList.add('hidden');
    if (afterHoursCard) afterHoursCard.classList.remove('hidden');

    const iconWrapper = document.getElementById('afterHoursIconWrapper');
    const unclosedTag = document.getElementById('afterHoursUnclosedTag');
    const unclosedCountEl = document.getElementById('afterHoursUnclosedCount');
    const headline = document.getElementById('afterHoursHeadline');
    const subtext = document.getElementById('afterHoursSubtext');
    const actionContainer = document.getElementById('afterHoursActionContainer');
    const pillText = document.getElementById('afterHoursPillText');

    if (pillText) {
      pillText.textContent = clinicState.isSunday ? 'Sunday Closed' : 'After Hours';
    }

    if (clinicState.isSunday) {
      if (afterHoursCard) {
        afterHoursCard.className = 'p-4 bg-white text-slate-800 rounded-xl shadow-xs flex items-center justify-between border border-slate-200/90 border-l-4 border-l-slate-400 transition';
      }
      if (iconWrapper) {
        iconWrapper.className = 'w-11 h-11 rounded-xl bg-slate-100 text-slate-600 border border-slate-200/80 flex items-center justify-center shrink-0';
        iconWrapper.innerHTML = `
          <svg class="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5" />
          </svg>
        `;
      }
      if (unclosedTag) unclosedTag.classList.add('hidden');
      if (headline) headline.textContent = `Clinic Closed Today (Sunday)`;
      if (subtext) subtext.textContent = `Klinik Pergigian Sofea is closed on Sundays. The clinic reopens tomorrow (Monday) at 9:00 AM.`;
      if (actionContainer) {
        actionContainer.innerHTML = `
          <a href="dentist.html" class="px-3.5 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition shadow-xs flex items-center gap-1.5">
            <svg class="w-3.5 h-3.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            View Tomorrow's Schedule
          </a>
        `;
      }
    } else if (pending.length > 0) {
      // Unclosed appointments remain from earlier today (e.g. Tan Mei Ling at 12:00 PM)
      const unclosed = pending[0];
      const unclosedTime = formatTime12h(unclosed.time);
      const unclosedTreatment = unclosed.details || (window.Clinic.TREATMENTS && window.Clinic.TREATMENTS[unclosed.treatmentId]?.name) || 'Consultation';

      if (afterHoursCard) {
        afterHoursCard.className = 'p-4 bg-amber-50/20 text-slate-800 rounded-xl shadow-xs flex items-center justify-between border border-amber-200/90 border-l-4 border-l-amber-500 transition';
      }

      if (iconWrapper) {
        iconWrapper.className = 'w-11 h-11 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center shrink-0';
        iconWrapper.innerHTML = `
          <svg class="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
          </svg>
        `;
      }

      if (unclosedTag) unclosedTag.classList.remove('hidden');
      if (unclosedCountEl) unclosedCountEl.textContent = pending.length;
      if (headline) headline.textContent = `Daily Clinical Wrap-Up • Action Required`;
      if (subtext) {
        subtext.innerHTML = `
          <strong class="text-slate-900 font-semibold">${escapeHtml(unclosed.patientName)}</strong> (${escapeHtml(unclosedTreatment)} • ${unclosedTime}) was scheduled today but was not checked out before 5:00 PM closing.
        `;
      }
      if (actionContainer) {
        actionContainer.innerHTML = `
          <button class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs transition flex items-center gap-1.5 shadow-xs btn-quick-close" data-id="${unclosed.id}">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.2"><path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>
            Complete Checkout
          </button>
          <button class="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-medium rounded-lg text-xs transition shadow-xs btn-quick-noshow" data-id="${unclosed.id}">
            Mark No-Show
          </button>
        `;
      }
    } else {
      // All appointments for today have been attended/closed
      if (afterHoursCard) {
        afterHoursCard.className = 'p-4 bg-white text-slate-800 rounded-xl shadow-xs flex items-center justify-between border border-slate-200/90 border-l-4 border-l-blue-600 transition';
      }
      if (iconWrapper) {
        iconWrapper.className = 'w-11 h-11 rounded-xl bg-blue-50 text-blue-600 border border-blue-200/80 flex items-center justify-center shrink-0';
        iconWrapper.innerHTML = `
          <svg class="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        `;
      }
      if (unclosedTag) unclosedTag.classList.add('hidden');
      if (headline) headline.textContent = `Daily Clinical Wrap-Up • Session Closed`;
      if (subtext) {
        subtext.textContent = `Clinic operating hours ended at 5:00 PM. All ${completed.length} scheduled procedures for today have concluded.`;
      }
      if (actionContainer) {
        actionContainer.innerHTML = `
          <a href="past-records.html" class="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs transition shadow-xs flex items-center gap-2">
            <svg class="w-4 h-4 text-blue-100" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            View Full History
          </a>
        `;
      }
    }

  // =========================================================================
  // STATE 2: CLINIC OPEN & ACTIVE CONSULTATION IN PROGRESS (Daytime 9 AM - 5 PM)
  // =========================================================================
  } else if (inConsult) {
    if (afterHoursCard) afterHoursCard.classList.add('hidden');
    if (noActiveCard) noActiveCard.classList.add('hidden');
    if (activeCard) activeCard.classList.remove('hidden');

    const activeName = document.getElementById('activePatientName');
    const activeDetail = document.getElementById('activePatientDetail');
    const activeBtnFinish = document.getElementById('btnFinishActiveConsultation');
    const btnOpenActiveChart = document.getElementById('btnOpenActiveChart');
    const elapsedBadge = document.getElementById('consultationElapsedBadge');
    const elapsedText = document.getElementById('consultationElapsedText');
    const overrunBadge = document.getElementById('consultationOverrunBadge');
    const overrunText = document.getElementById('consultationOverrunText');
    const startTimeEl = document.getElementById('activeStartTime');
    const durationEl = document.getElementById('activeDuration');
    const remainingEl = document.getElementById('activeRemainingTime');
    const remainingWrapper = document.getElementById('activeRemainingWrapper');

    const timing = getConsultationTiming(inConsult);

    if (activeName) activeName.textContent = inConsult.patientName;
    if (activeDetail) {
      const treatmentName = inConsult.details || (window.Clinic.TREATMENTS && window.Clinic.TREATMENTS[inConsult.treatmentId]?.name) || inConsult.treatmentId || 'Consultation';
      activeDetail.textContent = `${treatmentName} • Room 2 • Scheduled ${formatTime12h(inConsult.time)}`;
    }

    if (startTimeEl) startTimeEl.textContent = timing.startTimeFormatted;
    if (durationEl) durationEl.textContent = `${timing.duration} min`;
    if (elapsedText) elapsedText.textContent = `${timing.elapsed} mins`;

    if (timing.isOverrun) {
      if (overrunBadge) overrunBadge.classList.remove('hidden');
      if (overrunText) overrunText.textContent = `${timing.overrunMins}m`;
      if (remainingWrapper) remainingWrapper.classList.add('hidden');
    } else {
      if (overrunBadge) overrunBadge.classList.add('hidden');
      if (remainingWrapper) remainingWrapper.classList.remove('hidden');
      if (remainingEl) remainingEl.textContent = `${timing.remaining}m remaining`;
    }

    if (btnOpenActiveChart) {
      btnOpenActiveChart.onclick = () => {
        try { sessionStorage.setItem('selectedApptId', inConsult.id); } catch (e) {}
      };
    }

    if (activeBtnFinish) {
      activeBtnFinish.onclick = () => updatePatientStatus(inConsult.id, 'Completed');
    }

  // =========================================================================
  // STATE 3: CLINIC OPEN & ROOM READY FOR NEXT PATIENT (Daytime 9 AM - 5 PM)
  // =========================================================================
  } else {
    if (afterHoursCard) afterHoursCard.classList.add('hidden');
    if (activeCard) activeCard.classList.add('hidden');
    if (noActiveCard) noActiveCard.classList.remove('hidden');

    const headline = document.getElementById('readyRoomHeadline');
    const subtext = document.getElementById('readyRoomSubtext');
    const actionContainer = document.getElementById('readyRoomActionContainer');

    const visiblePending = appts.filter(a => a.statusPill !== 'Completed' && a.statusPill !== 'Canceled' && a.statusPill !== 'Cancelled' && a.statusPill !== 'No-Show');

    if (visiblePending.length > 0) {
      const nextAppt = visiblePending[0];
      const nextTime = formatTime12h(nextAppt.time);
      const nextTreatment = nextAppt.details || (window.Clinic.TREATMENTS && window.Clinic.TREATMENTS[nextAppt.treatmentId]?.name) || 'Consultation';

      if (headline) headline.textContent = `Ready for Next Consultation`;
      if (subtext) subtext.innerHTML = `Next patient in queue: <strong class="text-slate-800">${escapeHtml(nextAppt.patientName)}</strong> (${escapeHtml(nextTreatment)} • ${nextTime})`;
      if (actionContainer) {
        actionContainer.innerHTML = `
          <button class="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm btn-call-appt" data-id="${nextAppt.id}">
            <i class="fa-solid fa-bell"></i> Call In Patient
          </button>
        `;
      }
    } else {
      if (headline) headline.textContent = `All Consultations Completed for Today`;
      if (subtext) subtext.textContent = `All scheduled patients for Dr. Zar today have been attended to.`;
      if (actionContainer) {
        actionContainer.innerHTML = `
          <span class="text-xs text-emerald-700 font-bold bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg flex items-center gap-1">
            <i class="fa-solid fa-circle-check"></i> Queue Clear
          </span>
        `;
      }
    }
  }

  // =========================================================================
  // Pending Queue List Rendering
  // =========================================================================
  const pendingList = document.getElementById('pendingQueueList');
  const pendingBadge = document.getElementById('pendingBadge');
  const visiblePending = appts.filter(a => a.statusPill !== 'Completed' && a.statusPill !== 'Canceled' && a.statusPill !== 'Cancelled' && a.statusPill !== 'No-Show');

  if (pendingBadge) {
    pendingBadge.textContent = `${pending.length} WAITING`;
  }

  if (pendingList) {
    pendingList.innerHTML = '';
    if (visiblePending.length === 0) {
      pendingList.innerHTML = `<li class="p-6 text-center text-xs text-slate-400"><i class="fa-solid fa-circle-check text-emerald-500 me-1"></i> No pending patients in queue</li>`;
    } else {
      visiblePending.forEach(appt => {
        const rt = getApptRealtimeStatus(appt, clinicState);
        const timeDisplay = formatTime12h(appt.time);
        const treatmentName = appt.details || (window.Clinic.TREATMENTS && window.Clinic.TREATMENTS[appt.treatmentId]?.name) || appt.treatmentId || 'Consultation';
        const isInConsult = (appt.statusPill === 'In Consultation') && clinicState.isOpen;

        const li = document.createElement('li');
        li.className = `p-4 hover:bg-slate-50 transition cursor-default flex items-center justify-between ${isInConsult ? 'bg-blue-50/40' : ''}`;
        
        let actionsHtml = '';
        if (clinicState.isAfterHours) {
          actionsHtml = `
            <button class="px-2.5 py-1 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition shadow-xs flex items-center gap-1 btn-complete-appt" data-id="${appt.id}" title="Complete checkout">
              <i class="fa-solid fa-check"></i> Done
            </button>
            <button class="px-2 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-200 bg-slate-100 rounded-lg transition border border-slate-200 btn-noshow-appt" data-id="${appt.id}" title="Mark as No-Show">
              No-Show
            </button>
            <a href="dentist.html" class="p-1.5 text-slate-400 hover:text-blue-600 transition btn-patient-chart" data-id="${appt.id}" title="Open patient chart & calendar">
              <i class="fa-solid fa-calendar-check"></i>
            </a>
          `;
        } else if (isInConsult) {
          actionsHtml = `
            <button class="px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition shadow-xs flex items-center gap-1 btn-complete-appt" data-id="${appt.id}" title="Mark procedure completed">
              <i class="fa-solid fa-check"></i> Done
            </button>
            <a href="dentist.html" class="p-1.5 text-slate-400 hover:text-blue-600 transition btn-patient-chart" data-id="${appt.id}" title="Open patient chart & calendar">
              <i class="fa-solid fa-calendar-check"></i>
            </a>
          `;
        } else {
          actionsHtml = `
            <button class="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs flex items-center gap-1 btn-call-appt" data-id="${appt.id}" title="Call patient into consultation room">
              <i class="fa-solid fa-bell"></i> Call In
            </button>
            <a href="dentist.html" class="p-1.5 text-slate-400 hover:text-blue-600 transition btn-patient-chart" data-id="${appt.id}" title="Open patient chart & calendar">
              <i class="fa-solid fa-calendar-check"></i>
            </a>
          `;
        }

        li.innerHTML = `
          <div class="flex-1 min-w-0 pr-3">
            <div class="flex items-center gap-2">
              <p class="font-bold text-sm text-slate-800 uppercase tracking-wide truncate mb-0">${escapeHtml(appt.patientName)}</p>
              ${isInConsult ? `
                <span class="inline-flex items-center gap-1 text-[10px] text-blue-700 font-bold bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-full">
                  <span class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span> IN ROOM
                </span>
              ` : ''}
            </div>
            <p class="text-xs font-medium text-slate-500 mt-0.5 truncate">${escapeHtml(treatmentName)}</p>
          </div>
          <div class="text-right shrink-0 flex items-center gap-3">
            <div class="text-right">
              <span class="text-xs font-bold text-slate-700 block">${timeDisplay}</span>
              <span class="text-[10px] ${rt.badgeClass} px-2 py-0.5 rounded border mt-0.5 inline-block">${rt.badgeText}</span>
              <span class="text-[10px] text-slate-400 block mt-0.5">${rt.subtext}</span>
            </div>
            <div class="flex items-center gap-1.5">
              ${actionsHtml}
            </div>
          </div>
        `;
        pendingList.appendChild(li);
      });
    }
  }

  // =========================================================================
  // Completed Queue List Rendering
  // =========================================================================
  const completedList = document.getElementById('completedQueueList');
  const completedBadge = document.getElementById('completedBadge');
  const visibleCompleted = appts.filter(a => a.statusPill === 'Completed');

  if (completedBadge) {
    completedBadge.textContent = `${completed.length} DONE`;
  }

  if (completedList) {
    completedList.innerHTML = '';
    if (visibleCompleted.length === 0) {
      completedList.innerHTML = `<li class="p-6 text-center text-xs text-slate-400">No completed procedures recorded yet today</li>`;
    } else {
      visibleCompleted.forEach(appt => {
        const timeDisplay = formatTime12h(appt.time);
        const doneDisplay = appt.actualEndTime ? formatTime12h(appt.actualEndTime) : '';
        const treatmentName = appt.details || (window.Clinic.TREATMENTS && window.Clinic.TREATMENTS[appt.treatmentId]?.name) || appt.treatmentId || 'Consultation';

        let timingPill = '';
        if (appt.timingStatus === 'overrun' && appt.timingDiffMinutes) {
          timingPill = `<span class="text-[10px] text-amber-700 font-bold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">+${appt.timingDiffMinutes}m OVERRUN</span>`;
        } else if (appt.timingStatus === 'earlier' && appt.timingDiffMinutes) {
          timingPill = `<span class="text-[10px] text-blue-700 font-bold bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">${Math.abs(appt.timingDiffMinutes)}m EARLY</span>`;
        } else if (appt.timingStatus === 'on-time') {
          timingPill = `<span class="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">ON TIME</span>`;
        }

        const li = document.createElement('li');
        li.className = 'p-4 hover:bg-slate-50 transition cursor-default flex items-center justify-between';
        li.innerHTML = `
          <div class="flex-1 min-w-0 pr-3">
            <p class="font-bold text-sm text-slate-800 uppercase tracking-wide truncate mb-0">${escapeHtml(appt.patientName)}</p>
            <p class="text-xs font-medium text-slate-500 mt-0.5 truncate">${escapeHtml(treatmentName)}</p>
            ${appt.notes ? `<p class="text-[11px] text-slate-400 italic mt-0.5 truncate max-w-sm mb-0"><i class="fa-regular fa-note-sticky me-1"></i>${escapeHtml(appt.notes)}</p>` : ''}
          </div>
          <div class="text-right shrink-0">
            <span class="text-xs font-bold text-slate-700 block">${timeDisplay}</span>
            <div class="flex items-center justify-end gap-1 mt-1">
              ${timingPill}
              <span class="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 inline-block">COMPLETED</span>
            </div>
            ${doneDisplay ? `<span class="text-[10px] text-slate-400 block mt-0.5">Finished ${doneDisplay}</span>` : ''}
          </div>
        `;
        completedList.appendChild(li);
      });
    }
  }

  bindActionButtons();
}

function bindActionButtons() {
  document.querySelectorAll('.btn-call-appt').forEach(btn => {
    btn.onclick = (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      updatePatientStatus(id, 'In Consultation');
    };
  });

  document.querySelectorAll('.btn-complete-appt, .btn-quick-close').forEach(btn => {
    btn.onclick = (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      updatePatientStatus(id, 'Completed');
    };
  });

  document.querySelectorAll('.btn-noshow-appt, .btn-quick-noshow').forEach(btn => {
    btn.onclick = (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      updatePatientStatus(id, 'No-Show');
    };
  });

  document.querySelectorAll('.btn-patient-chart').forEach(btn => {
    btn.onclick = (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      try { sessionStorage.setItem('selectedApptId', id); } catch (err) {}
    };
  });
}

function updatePatientStatus(apptId, newStatus) {
  const now = new Date();
  const nowHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const patch = { statusPill: newStatus };

  if (newStatus === 'In Consultation') {
    // If another appointment was in consultation, mark it completed or shift it
    if (window.Clinic && window.Clinic.APPOINTMENTS) {
      window.Clinic.APPOINTMENTS.forEach(a => {
        if (a.statusPill === 'In Consultation' && a.id !== apptId) {
          a.statusPill = 'Completed';
          a.actualEndTime = nowHHMM;
          if (window.Clinic.app && window.Clinic.app.updateAppointment) {
            window.Clinic.app.updateAppointment(a.id, { statusPill: 'Completed', actualEndTime: nowHHMM });
          }
        }
      });
    }

    patch.consultationStartTime = nowHHMM;
  } else if (newStatus === 'Completed') {
    patch.actualEndTime = nowHHMM;

    // Calculate timing diff vs scheduled end time
    const appt = window.Clinic && window.Clinic.APPOINTMENTS && window.Clinic.APPOINTMENTS.find(a => a.id === apptId);
    if (appt) {
      const endMins = now.getHours() * 60 + now.getMinutes();
      const schedEnd = parseTimeHHMM(appt.endTime || appt.time);
      const diff = endMins - schedEnd;
      patch.timingDiffMinutes = diff;
      patch.timingStatus = diff > 5 ? 'overrun' : (diff < -5 ? 'earlier' : 'on-time');
    }
  } else if (newStatus === 'No-Show') {
    patch.notes = 'Patient did not attend appointment (marked no-show).';
  }

  if (window.Clinic && window.Clinic.app && window.Clinic.app.updateAppointment) {
    window.Clinic.app.updateAppointment(apptId, patch);
  } else if (window.Clinic && window.Clinic.APPOINTMENTS) {
    const a = window.Clinic.APPOINTMENTS.find(item => item.id === apptId);
    if (a) Object.assign(a, patch);
  }

  renderDashboard();

  if (window.Clinic && window.Clinic.app && window.Clinic.app.showToast) {
    let title = 'Status Updated';
    let msg = 'Appointment status updated.';

    if (newStatus === 'In Consultation') {
      title = 'Patient Called In';
      msg = 'Patient status updated to In Consultation (Room 2).';
    } else if (newStatus === 'Completed') {
      title = 'Consultation Completed';
      msg = 'Appointment marked as Completed. Clinical records synced in real time.';
    } else if (newStatus === 'No-Show') {
      title = 'Marked as No-Show';
      msg = 'Appointment marked as No-Show and archived.';
    }

    window.Clinic.app.showToast(title, msg, 'success');
  }
}

function initDentistDashboard() {
  updateLiveClock();

  // Search Input Handler
  const searchInput = document.getElementById('patientSearchInput');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      renderDashboard();
    });
  }

  renderDashboard();

  // Real-time ticking clock every second
  setInterval(updateLiveClock, 1000);

  // Real-time queue and timer re-computation heartbeat every 10 seconds
  setInterval(renderDashboard, 10000);

  // Cross-tab real-time sync with Front Desk & Calendar via Storage Events
  window.addEventListener('storage', (e) => {
    if (e.key === 'kpst.v1.appointments' || e.key === 'kpst.v1.seedDate') {
      if (window.Clinic && window.Clinic.app && window.Clinic.app.hydrate) {
        window.Clinic.app.hydrate();
      }
      renderDashboard();
    }
  });
}

function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  if (sidebar) {
    sidebar.classList.toggle('hidden');
  }
}
