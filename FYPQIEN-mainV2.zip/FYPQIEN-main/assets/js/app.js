(function (window) {
  'use strict';

  const Clinic = window.Clinic || {};
  const utils = Clinic.utils || {};

  /* ------------------------------------------------------------------ *
   * Storage helpers (localStorage → sessionStorage → in-memory fallback)
   * ------------------------------------------------------------------ */
  var KEYS = {
    appointments: 'kpst.v1.appointments',
    reminders: 'kpst.v1.reminders',
    seedDate: 'kpst.v1.seedDate',
    clinicalNotes: 'kpst.v1.clinical_notes',
    dentistProfile: 'kpst.v1.dentist_profile'
  };
  var memoryStore = {};

  function storageGet(key) {
    try {
      var v = window.localStorage.getItem(key);
      if (v !== null && v !== undefined) return v;
    } catch (e) { /* ignore */ }
    try {
      var v2 = window.sessionStorage.getItem(key);
      if (v2 !== null && v2 !== undefined) return v2;
    } catch (e) { /* ignore */ }
    return Object.prototype.hasOwnProperty.call(memoryStore, key) ? memoryStore[key] : null;
  }

  function storageSet(key, value) {
    memoryStore[key] = value;
    try { window.localStorage.setItem(key, value); } catch (e) { /* ignore */ }
    try { window.sessionStorage.setItem(key, value); } catch (e) { /* ignore */ }
  }

  function storageRemove(key) {
    delete memoryStore[key];
    try { window.localStorage.removeItem(key); } catch (e) { /* ignore */ }
    try { window.sessionStorage.removeItem(key); } catch (e) { /* ignore */ }
  }

  function storageGetJSON(key) {
    var raw = storageGet(key);
    if (raw === null || raw === undefined || raw === '') return null;
    try { return JSON.parse(raw); } catch (e) { return null; }
  }

  function storageSetJSON(key, obj) {
    try { storageSet(key, JSON.stringify(obj)); } catch (e) { /* ignore */ }
  }

  Clinic.storage = {
    KEYS: KEYS,
    get: storageGet,
    set: storageSet,
    remove: storageRemove,
    getJSON: storageGetJSON,
    setJSON: storageSetJSON
  };

  /* ------------------------------------------------------------------ *
   * Inline SVG icon set (stroke = currentColor, no external assets)
   * ------------------------------------------------------------------ */
  function svgMark(paths, fill) {
    if (fill) {
      return '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' + paths + '</svg>';
    }
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths + '</svg>';
  }

  var ICONS = {
    tooth: svgMark('<path d="M12 3.4c-3.7 0-6.6 2.3-6.6 5.3 0 1.8.7 3.2 1.6 4.7.6 1.1 1.1 2.7 1.7 3.7.5.9 1 1.6 1.8 1.6s1.6-.6 2-1.6c.3-.7.6-1.4 1-1.4s.7.7 1 1.4c.4 1 .7 1.6 2 1.6s1.3-.7 1.8-1.6c.6-1 1.1-2.6 1.7-3.7.9-1.5 1.6-2.9 1.6-4.7 0-3-2.9-5.3-7.6-5.3z" />', true),
    phone: svgMark('<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />'),
    note: svgMark('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /><path d="M16 13H8" /><path d="M16 17H8" /><path d="M10 9H8"'),
    edit: svgMark('<path d="M12 20h9" /><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"'),
    trash: svgMark('<path d="M3 6h18" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" /><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /><path d="M10 11v6" /><path d="M14 11v6"'),
    check: svgMark('<path d="M20 6 9 17l-5-5"'),
    alert: svgMark('<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><path d="M12 9v4" /><path d="M12 17h.01"'),
    info: svgMark('<circle cx="12" cy="12" r="10" /><path d="M12 16v-4" /><path d="M12 8h.01"'),
    bell: svgMark('<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0"'),
    lock: svgMark('<rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4"'),
    close: svgMark('<path d="M18 6 6 18" /><path d="M6 6l12 12"'),
    clock: svgMark('<circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2"'),
    plus: svgMark('<path d="M12 5v14" /><path d="M5 12h14"'),
    chevronLeft: svgMark('<path d="M15 18l-6-6 6-6"'),
    chevronRight: svgMark('<path d="M9 18l6-6-6-6"'),
    calendar: svgMark('<rect x="3" y="4" width="18" height="18" rx="2" ry="2" /><path d="M16 2v4" /><path d="M8 2v4" /><path d="M3 10h18"'),
    clipboard: svgMark('<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /><rect x="8" y="2" width="8" height="4" rx="1" ry="1" />'),
    stethoscope: svgMark('<path d="M5 3v5a5 5 0 0 0 10 0V3" /><path d="M10 13v4" /><path d="M10 17a4 4 0 0 0 8 0v-1.5" /><circle cx="6" cy="5" r="1.4" /><circle cx="14" cy="5" r="1.4"'),
    send: svgMark('<path d="M22 2 11 13" /><path d="M22 2 15 22l-4-9-9-4z"'),
    refresh: svgMark('<path d="M23 4v6h-6" /><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"'),
    inbox: svgMark('<path d="M22 12h-6l-2 3h-4l-2-3H2" /><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"')
  };

  /* ------------------------------------------------------------------ *
   * Helpers
   * ------------------------------------------------------------------ */
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function getTreatmentById(id) {
    var list = Clinic.TREATMENTS || [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) return list[i];
    }
    return { id: id, name: 'Treatment', color: 'var(--treatment-default)' };
  }

  /* ------------------------------------------------------------------ *
   * Role handling
   * ------------------------------------------------------------------ */
  function getRole() {
    try { return window.sessionStorage.getItem('clinicRole'); } catch (e) { return null; }
  }

  function setRole(role) {
    try {
      if (role === 'admin' || role === 'dentist') {
        window.sessionStorage.setItem('clinicRole', role);
      }
    } catch (e) { /* ignore */ }
  }

  function clearRole() {
    try { window.sessionStorage.removeItem('clinicRole'); } catch (e) { /* ignore */ }
  }

  function enforceRole(requiredRoles) {
    var role = getRole();
    if (!role) {
      window.location.href = 'index.html';
      return false;
    }
    if (requiredRoles.indexOf(role) === -1) {
      showAccessDenied();
      return false;
    }
    return true;
  }

  function showAccessDenied() {
    var denied = document.getElementById('accessDenied');
    var content = document.getElementById('dashboard') ||
      document.getElementById('dentistView') ||
      document.getElementById('remindersView');
    if (denied) denied.classList.remove('hidden');
    if (content) content.classList.add('hidden');
    initRoleBadge();
    initLogout();
    initBackToIndex();
  }

  function initRoleBadge() {
    var badge = document.querySelector('[data-role-badge]');
    if (!badge) return;
    var role = getRole();
    var label = 'Guest';
    var cls = 'guest';
    if (role === 'admin') { label = 'Admin Staff'; cls = 'admin'; }
    else if (role === 'dentist') { label = 'Dentist (Read-only)'; cls = 'dentist'; }
    badge.className = 'role-badge role-' + cls;
    badge.setAttribute('aria-label', label);
    badge.innerHTML = '<span class="role-dot" aria-hidden="true"></span><span class="role-label">' + escapeHtml(label) + '</span>';
  }

  function initLogout() {
    var btn = document.getElementById('logoutBtn');
    if (btn) {
      btn.addEventListener('click', function () {
        clearRole();
        window.location.href = 'index.html';
      });
    }
  }

  function initBackToIndex() {
    var btn = document.getElementById('backToIndex');
    if (btn) {
      btn.addEventListener('click', function () {
        window.location.href = 'index.html';
      });
    }
  }

  /* ------------------------------------------------------------------ *
   * Appointment hydration / persistence
   * ------------------------------------------------------------------ */
  function persistAppointments() {
    if (Array.isArray(Clinic.APPOINTMENTS)) {
      storageSetJSON(KEYS.appointments, Clinic.APPOINTMENTS);
    }
  }

  function updateAppointment(id, patch) {
    if (!Array.isArray(Clinic.APPOINTMENTS)) return null;
    for (var i = 0; i < Clinic.APPOINTMENTS.length; i++) {
      if (Clinic.APPOINTMENTS[i].id === id) {
        Object.assign(Clinic.APPOINTMENTS[i], patch);
        Clinic.APPOINTMENTS[i].id = id; // Ensure ID cannot be changed
        persistAppointments();
        return Clinic.APPOINTMENTS[i];
      }
    }
    return null;
  }

  function hydrate() {
    var todayISO = (Clinic.utils && Clinic.utils.toDateISO) 
      ? Clinic.utils.toDateISO(new Date()) 
      : new Date().toISOString().split('T')[0];

    // Version check to clear corrupted or legacy data (2.2 clears evening appointments past 5 PM and aligns standard clinic hours)
    var version = storageGet('kpst.v1.version');
    if (version !== '2.2') {
      storageRemove(KEYS.appointments);
      storageRemove(KEYS.reminders);
      storageRemove('kpst.v1.patient_call_event');
      storageRemove('kpst.v1.calling_patient_id');
      storageSet('kpst.v1.version', '2.2');
    }

    var storedDate = storageGet(KEYS.seedDate);
    var stored = storageGetJSON(KEYS.appointments);

    // Check if stored appointments exist and are still relevant for today
    var isStale = false;
    if (stored && Array.isArray(stored) && stored.length > 0) {
      if (storedDate && storedDate !== todayISO) {
        // Date has rolled over since last session
        var hasToday = stored.some(function (a) { return a.dateISO === todayISO; });
        if (!hasToday) isStale = true;
      }
    }

    if (stored && Array.isArray(stored) && !isStale) {
      // Safety guarantee: Filter out any appointments falling on Sundays (Clinic Closed)
      Clinic.APPOINTMENTS = stored.filter(function (a) {
        if (!a.dateISO) return true;
        var d = new Date(a.dateISO + 'T00:00:00');
        return d.getDay() !== 0;
      });

      // Clean up appointments past 5:00 PM (17:00) and any dummy testing entries
      Clinic.APPOINTMENTS = Clinic.APPOINTMENTS.filter(function (a) {
        if (!a) return false;
        if (a.id === 'appt-today-7-evening' || a.id === 'appt-today-8-evening' || a.id === 'appt-today-9-evening') return false;
        if (a.dateISO === todayISO) {
          // Purge test appointments created during testing
          if (a.patientName === 'hhh' || a.patientName === 'vubg' || a.patientName === 'Hakim bin Danial' || a.patientName === 'iii' || a.patientName === 'yty' || a.patientName === 'bjkbk' || a.notes === 'Evening testing session 9:00 PM' || a.notes === 'Evening testing session' || a.phone === '999' || a.phone === '0000') {
            return false;
          }
          // Remove all appointments past 5:00 PM (17:00)
          if (a.time && a.time >= '17:00') {
            return false;
          }
          // Remove any non-canonical appointment inserted at 10:00 or 10:30 (only appt-today-2 is seed)
          if ((a.time === '10:00' || a.time === '10:30') && a.id !== 'appt-today-2') {
            return false;
          }
        }
        return true;
      });

      // Clear any pending call notification for purged patients or past 5 PM
      try {
        var callEv = storageGetJSON('kpst.v1.patient_call_event');
        if (callEv && (
          callEv.patientName === 'hhh' || 
          callEv.patientName === 'vubg' || 
          callEv.patientName === 'bjkbk' || 
          callEv.patientName === 'iii' || 
          callEv.patientName === 'yty' || 
          callEv.patientName === 'Hakim bin Danial' || 
          callEv.apptId === 'appt-today-7-evening' || 
          callEv.apptId === 'appt-today-8-evening' || 
          callEv.apptId === 'appt-today-9-evening' || 
          (callEv.time && (callEv.time >= '17:00' || ((callEv.time === '10:00' || callEv.time === '10:30') && callEv.apptId !== 'appt-today-2')))
        )) {
          storageRemove('kpst.v1.patient_call_event');
          storageRemove('kpst.v1.calling_patient_id');
        }
      } catch (e) {}

      storageSet(KEYS.seedDate, todayISO);
      persistAppointments();
      return true;
    }

    // Fresh session or date rolled over: regenerate seed anchored to today
    if (Clinic.mockData && Clinic.mockData.buildSeedAppointments) {
      Clinic.APPOINTMENTS = Clinic.mockData.buildSeedAppointments();
    }
    storageSet(KEYS.seedDate, todayISO);
    persistAppointments();
    return false;
  }

  /* ------------------------------------------------------------------ *
   * Toast system (icon + title + message + progress bar + auto-dismiss)
   * ------------------------------------------------------------------ */
  var TOAST_DURATION = 4000;

  function removeToast(toast) {
    if (!toast) return;
    toast.classList.remove('show');
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(12px) scale(0.97)';
    setTimeout(function () {
      if (toast && toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 240);
  }

  function showToast(title, message, type) {
    var validTypes = ['success', 'error', 'cancel', 'info', 'warning'];

    // Handle 2-argument signature: showToast('Appointment booked', 'success')
    if (arguments.length === 2 && validTypes.indexOf(message) !== -1) {
      type = message;
      message = '';
    } else if (typeof message !== 'string') {
      type = message;
      message = '';
    }
    type = type || 'info';
    var container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
      container.style.cssText = 'position: fixed; bottom: 1.5rem; right: 1.5rem; z-index: 9999; display: flex; flex-direction: column; gap: 0.5rem; pointer-events: none;';
      document.body.appendChild(container);
    }

    var icon = ICONS.info;
    if (type === 'success') icon = ICONS.check;
    else if (type === 'error') icon = ICONS.alert;
    else if (type === 'cancel') icon = ICONS.close;

    var toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.setAttribute('role', 'status');

    toast.innerHTML =
      '<span class="toast-icon">' + icon + '</span>' +
      '<span class="toast-content">' +
      '<span class="toast-title">' + escapeHtml(title) + '</span>' +
      (message ? '<span class="toast-message">' + escapeHtml(message) + '</span>' : '') +
      '</span>' +
      '<button type="button" class="toast-close" aria-label="Dismiss">' + ICONS.close + '</button>' +
      '<span class="toast-progress" aria-hidden="true"></span>';

    container.appendChild(toast);

    var timerId = null;

    var closeBtn = toast.querySelector('.toast-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (timerId) clearTimeout(timerId);
        removeToast(toast);
      });
    }

    requestAnimationFrame(function () {
      toast.classList.add('show');
    });

    timerId = setTimeout(function () {
      removeToast(toast);
    }, TOAST_DURATION);
  }

  function playChime() {
    try {
      var AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      var ctx = new AudioCtx();
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch (e) { /* ignore */ }
  }

  /* ------------------------------------------------------------------ *
   * Public API
   * ------------------------------------------------------------------ */
  function resetData() {
    storageRemove(KEYS.appointments);
    storageRemove(KEYS.reminders);
    storageRemove(KEYS.seedDate);
    storageRemove(KEYS.clinicalNotes);
    window.location.reload();
  }

  Clinic.app = {
    getRole: getRole,
    getCurrentRole: getRole,
    setRole: setRole,
    clearRole: clearRole,
    enforceRole: enforceRole,
    showAccessDenied: showAccessDenied,
    initRoleBadge: initRoleBadge,
    initLogout: initLogout,
    initBackToIndex: initBackToIndex,
    hydrate: hydrate,
    persistAppointments: persistAppointments,
    updateAppointment: updateAppointment,
    showToast: showToast,
    playChime: playChime,
    escapeHtml: escapeHtml,
    getTreatmentById: getTreatmentById,
    resetData: resetData,
    icons: ICONS
  };

  window.Clinic = Clinic;

  // Hydrate from storage before any page script renders.
  hydrate();
})(window);