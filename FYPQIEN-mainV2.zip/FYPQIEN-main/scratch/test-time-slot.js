const fs = require('fs');

// Mock browser globals
global.window = global;
global.localStorage = {
  store: {},
  getItem: function(k) { return this.store[k] || null; },
  setItem: function(k, v) { this.store[k] = String(v); },
  removeItem: function(k) { delete this.store[k]; }
};

// Load scripts in order
require('../assets/js/mock-data.js');
require('../assets/js/app.js');

console.log('--- 1. Testing Seed Appointments ---');
const seedAppts = Clinic.mockData.buildSeedAppointments();
console.log('Total seed appointments count:', seedAppts.length);
const todayAppts = seedAppts.filter(a => a.dateISO === new Date().toISOString().split('T')[0]);
console.log('Today appointments times:', todayAppts.map(a => `${a.time} (${a.patientName})`));
const past5pmInSeed = todayAppts.filter(a => a.time >= '17:00');
if (past5pmInSeed.length > 0) {
  console.error('FAIL: Found appointments past 5 PM in seed:', past5pmInSeed);
  process.exit(1);
} else {
  console.log('PASS: No appointments past 5 PM in seed data.');
}

console.log('\n--- 2. Testing Hydrate Filter with Dummy and 10 / Evening appointments ---');
// Inject dummy test items into localStorage
const testAppointments = [
  ...todayAppts,
  { id: 'custom-1', dateISO: new Date().toISOString().split('T')[0], time: '10:00', patientName: 'Dummy 10am', statusPill: 'Waiting' },
  { id: 'custom-2', dateISO: new Date().toISOString().split('T')[0], time: '19:00', patientName: 'Dummy Evening', statusPill: 'Waiting' },
  { id: 'custom-3', dateISO: new Date().toISOString().split('T')[0], time: '22:00', patientName: 'Dummy 10pm', statusPill: 'Waiting' }
];

localStorage.setItem('kpst.v1.version', '2.2');
localStorage.setItem('kpst.v1.appointments', JSON.stringify(testAppointments));
localStorage.setItem('kpst.v1.seedDate', new Date().toISOString().split('T')[0]);

Clinic.app.hydrate();

const hydratedAppts = Clinic.APPOINTMENTS.filter(a => a.dateISO === new Date().toISOString().split('T')[0]);
console.log('Hydrated today appointments:', hydratedAppts.map(a => `${a.time} [${a.id}] ${a.patientName}`));

const hasPast5pm = hydratedAppts.some(a => a.time >= '17:00');
const hasDummy10 = hydratedAppts.some(a => a.id === 'custom-1');
const hasDummyEve = hydratedAppts.some(a => a.id === 'custom-2' || a.id === 'custom-3');

if (hasPast5pm || hasDummy10 || hasDummyEve) {
  console.error('FAIL: Dummy or past 5 PM items remained!');
  process.exit(1);
} else {
  console.log('PASS: All past 5 PM appointments and dummy 10 appointments successfully removed!');
}

console.log('\n--- 3. Testing Version 2.2 Reset Behavior ---');
// If version is old (e.g. 2.1 or 2.0), hydrate should wipe and rebuild
localStorage.setItem('kpst.v1.version', '2.1');
localStorage.setItem('kpst.v1.appointments', JSON.stringify([{ id: 'old-corrupted', time: '10:00' }]));

Clinic.app.hydrate();
console.log('Version in storage after upgrade:', localStorage.getItem('kpst.v1.version'));
console.log('Appointments count after fresh seed reload:', Clinic.APPOINTMENTS.length);
if (localStorage.getItem('kpst.v1.version') === '2.2' && !Clinic.APPOINTMENTS.some(a => a.id === 'old-corrupted')) {
  console.log('PASS: Version upgrade cleanly restored canonical seed appointments.');
} else {
  console.error('FAIL: Old version was not properly upgraded.');
  process.exit(1);
}

console.log('\nALL VERIFICATION CHECKS PASSED!');
